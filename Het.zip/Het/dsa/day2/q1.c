#include<stdio.h>
int n = 3;
int s[3],top=0;

int isfull()
{	
	if(top>=n)
		return 1;
	else
		return 0;
}
int push(int x)
{
	if(isfull() == 0)
	{
		top++;
		s[top] = x;
		return 1;
	}
	else
	{
		printf("Stack Overflow\n");
		return 0;
	}
}

void main()
{
	int i;
	while(1)
	{
		int x;
		printf("Enter a element to push \n");
		scanf("%d", &x);
		if(push(x) == 0)
			break;
		else
			printf("Element is pushed \n");
	}
	printf("Stack is:- ");
	for(i=0;i<4;i++)
		printf("%d ", s[i]);
	printf("\n");	
}
