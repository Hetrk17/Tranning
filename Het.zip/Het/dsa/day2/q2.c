#include<stdio.h>
int n = 3;
int emtyflag = 0;
int overflag = 0;
int isfull(int *top)
{	
	if(*top>=n)
		return 1;
	else
		return 0;
}
int isEt(int *top)
{	
	if(*top==0)
		return 1;
	else
		return 0;
}
int push(int a[4], int *top, int x)
{
	if(isfull(top) == 0)
	{
		*top = *top +1;
		a[*top] = x;
		return 1;
	}
	else
	{
		printf("Stack Overflow\n");
		return 0;
	}
}
int pop(int a[4], int *top)
{
	int x;
	if(isEt(top) == 0)
	{
		emtyflag = 0;
		x = a[*top];
		a[*top] = 0;
		*top = *top -1;
	} 
	else 
	{	
		emtyflag = 1;
		x = 0;
	}
	return x;
}
int peep(int a[4], int *top, int i)
{
	if(*top-i+1 <0)
	{
		overflag = 1;
		return 0;
	}
	else
	{
		overflag = 0;
		return a[*top-i+1];
	}
}
void change(int a[4], int *top, int i, int x)
{
	if(*top-i+1 <0)
	{
		overflag = 1;
	}
	else
	{
		a[*top-i+1] = x;
	}
}
void main()
{
	int i,index,ele;
	int s[4];
	int top,val;
	top = 0;
	int x;
	while(1)
	{

		printf("Enter a element to push \n");
		scanf("%d", &x);
		if(push(s,&top,x) == 0)
			break;
		else
			printf("Element is pushed \n");
	}
	printf("\n \n");
	printf("Stack is:- ");
	for(i=1;i<4;i++)
		printf("%d ", s[i]);
	printf("\n \n");
	printf("Peep \n");
	printf("\n");
	printf("Enter a index:-  \n");
	scanf("%d", &index);	
	val = peep(s,&top,index);
	if(overflag)
	{
		printf("%d index is not aveleble \n", index);
	}
	else
	{
		printf(" Value store at %d index is %d\n", index, val);
	}
	printf("\n \n");
	printf("Change \n");
	printf("\n");
	printf("Enter a index:-  \n");
	scanf("%d", &index);	
	printf("Enter a Elemnt:-  \n");
	scanf("%d", &ele);
	change(s,&top,index,ele);
	if(overflag)
	{
		printf("%d index is not aveleble \n", index);
	}
	else
	{
		printf("Element is change\n");
	}
	printf("\n Stack is:- ");
	for(i=1;i<4;i++)
		printf("%d ", s[i]);
	printf("\n\n");
	while(1)
	{
		if(emtyflag)
		{
			break;
		}
		else
			printf("Poped Element is %d \n", pop(s,&top));
	}
	printf("Stack is:- ");
	for(i=1;i<4;i++)
		printf("%d ", s[i]);
	printf("\n");
}
