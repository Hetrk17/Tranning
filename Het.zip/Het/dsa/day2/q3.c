#include<stdio.h>

int isfull(int *top, int n)
{	
	if(*top>=n)
		return 1;
	else
		return 0;
}
int isEt(int *top)
{	
	if(*top==0)
		return 1;
	else
		return 0;
}
int push(int a[4], int *top, int x, int n)
{
	if(isfull(top,n) == 0)
	{
		*top = *top +1;
		a[*top] = x;
		return 1;
	}
	else
	{
		printf("Stack Overflow\n");
		return 0;
	}
}
int pop(int a[4], int *top)
{
	int x;
	if(isEt(top) == 0)
	{
		x = a[*top];
		a[*top] = 0;
		*top = *top -1;
	} 
	else 
	{	
		printf("Stack is empty. Can not pop element");
		x = 0;
	}
	return x;
}
int peep(int a[4], int *top, int i)
{
	if(*top-i+1 <0)
	{
		printf("%d index is not aveleble \n", i);
		return 0;
	}
	else
	{
		return a[*top-i+1];
	}
}
void change(int a[4], int *top, int i, int x)
{
	if(*top-i+1 <0)
	{
		printf("%d index is not aveleble \n", i);
	}
	else
	{
		a[*top-i+1] = x;
		printf("Element is change\n");
	}
}
void main()
{
	int i,index,ele,choise,temp;
	int s[4] = {0,0,0,0};
	int top,val;
	top = 0;
	int x;
	int n = 3;
	while(1)
	{
		printf("\n 1:-  Push \n 2:- Pop \n 3:- Peep \n 4:- change \n 5:- Quit \n");
		printf("Enter your choise:- ");
		scanf("%d", &choise);
		if(choise == 1)
		{
			printf("Enter a element to push:- ");
			scanf("%d", &x);
			if(push(s,&top,x,n) == 0)
				printf("Can not push %d \n", x);
			else
				printf("Element is pushed \n");
			printf("\n \n");
			printf("Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n \n");
		}
		else if(choise == 2)
		{
			temp = pop(s,&top);
			if(temp == 0)
			{
				continue;
			}
			else
				printf("Poped Element is %d \n", temp);
			printf("Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n \n");
		}
		else if(choise == 3)
		{
			printf("Enter a index:-  ");
			scanf("%d", &index);	
			val = peep(s,&top,index);
			if(val == 0)
			{
				continue;
			}
			else
			{
				printf(" Value store at %d index is %d\n", index, val);
			}
			printf("\n \n");	
		}
		else if(choise == 4)
		{
			
			printf("Enter a index:-  ");
			scanf("%d", &index);	
			printf("Enter a Elemnt:-  ");
			scanf("%d", &ele);
			change(s,&top,index,ele);
			
			printf("\n Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n\n");
		}
		else if(choise == 5)
		{
			break;
		}
		else
		{
			printf("Enter a proper choise. \n");
		}
	}
}
	


