#include<stdio.h>
#include "stack.h"

void main()
{
	int i,index,ele,choise,temp;
	int s[4] = {0,0,0,0};
	int top,val;
	top = 0;
	int x;
	int n = 3;
	while(1)
	{
		printf("\n 1:-  Push \n 2:- Pop \n 3:- Peep \n 4:- change \n 5:- Quit \n");
		printf("Enter your choise:- ");
		scanf("%d", &choise);
		if(choise == 1)
		{
			printf("Enter a element to push:- ");
			scanf("%d", &x);
			if(push(s,&top,x,n) == 0)
				printf("Can not push %d \n", x);
			else
				printf("Element is pushed \n");
			printf("\n \n");
			printf("Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n \n");
		}
		else if(choise == 2)
		{
			temp = pop(s,&top);
			if(temp == 0)
			{
				continue;
			}
			else
				printf("Poped Element is %d \n", temp);
			printf("Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n \n");
		}
		else if(choise == 3)
		{
			printf("Enter a index:-  ");
			scanf("%d", &index);	
			val = peep(s,&top,index);
			if(val == 0)
			{
				continue;
			}
			else
			{
				printf(" Value store at %d index is %d\n", index, val);
			}
			printf("\n \n");	
		}
		else if(choise == 4)
		{
			
			printf("Enter a index:-  ");
			scanf("%d", &index);	
			printf("Enter a Elemnt:-  ");
			scanf("%d", &ele);
			change(s,&top,index,ele);
			
			printf("\n Stack is:- ");
			for(i=1;i<4;i++)
				printf("%d ", s[i]);
			printf("\n\n");
		}
		else if(choise == 5)
		{
			break;
		}
		else
		{
			printf("Enter a proper choise. \n");
		}
	}
}
	


