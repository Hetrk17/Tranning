#include<stdio.h>
#include<string.h>
#include "stack.h"

void main()
{
	int i,len,h,k,n,top;
	char c;
	top = 0;
	n = 10;
	char u[10];
	char a[10] = {'0','0','0','0','0','0','0','0','0','0'}; 
	printf("Enter a string:- ");
	scanf("%s", u);
	len = strlen(u);
	i=0;
	while(u[i] != 'a')
	{
		k = pushc(a,&top,u[i],n);
		i++;
	}
	
	while(i < (len))
	{
		c = popc(a,&top);
		if(c == '0')
		{
			break;
		}
		i++;
	}
	if((i == (len)) && (a[top] != 'b'))
	{
		printf("\nString has same number of a and b \n ");
	}
	else
	{
		printf("\nString has diffrent number of a and b  \n ");
	}

}
