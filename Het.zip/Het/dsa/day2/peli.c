#include<stdio.h>
#include<string.h>
#include "stack.h"

void main()
{
	int i,len,h,k,n,top;
	char c;
	top = 0;
	n = 10;
	char u[10];
	char a[10] = {'0','0','0','0','0','0','0','0','0','0'}; 
	printf("Enter a string:- ");
	scanf("%s", u);
	len = strlen(u);
	h = ((len-1)/2);
	for(i=0;i<h;i++)
	{
		k = pushc(a,&top,u[i],n); 
	}
	for(i=(h+1); i<len; i++)
	{
		c = popc(a,&top);
		printf("\n");
		if(c != u[i])
		{

			break;
		}
		if(c == '0')
		{

			break;
		}
	}
	if(i == len)
	{
		printf("String is pelindrome \n ");
	}
	else
	{
		printf("String is not pelindrome \n ");
	}
	
}
