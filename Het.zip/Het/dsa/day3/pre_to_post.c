#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define SIZE 100

int top;
char stack[SIZE];
int top = -1;
void push(char b)
{
    	if(top >= SIZE-1)
	{
		printf("\nStack Overflow.");
	}
	else
	{
		top = top +1;
		stack[top] = b;
	}


}
char pop()
{
    	char b;
    	if(top <0)
	{
		printf("stack is empty");
		return '\0';
	}
	else
	{
		b=stack[top];
		top = top -1;
		return b;
	}
}
int precedence(char symbol)
{
	if(symbol == '^')
	{
		return(3);
	}
	else if(symbol == '*' || symbol == '/')
	{
		return(2);
	}
	else if(symbol == '+' || symbol == '-')
	{
		return(1);
	}
	else
	{
		return(0);
	}
}
int is_operator(char symbol)
{
	if(symbol == '^' || symbol == '*' || symbol == '/' || symbol == '+' || symbol =='-')
	{
		return 1;
	}
	else if (symbol == '(' || symbol == ')')
	{
		return 2;
	}
	else
	{
		return 0;
	}
}
void InfixToPostfix(char infix_exp[], char postfix_exp[])
{
    	int i, j,k;
	char item;
	char x;

	push('(');
	strcat(infix_exp,")");
	i=0;
	j=0;
	item=infix_exp[i];
	while (item != '\0')
	{
		//printf("%c", item);
		//k = precedence(item);
		//printf("%d",k);
		if(item == '(')
		{
	  	 //printf("a \n");
			push(item);
		}
		else if(isdigit(item) || isalpha(item))
		{
			//printf("b \n");
			postfix_exp[j] = item;
			j++;
		}
		else if(is_operator(item) == 1)
		{
			x=pop();
			//printf("c \n");
			while(is_operator(x) == 1 && precedence(x)>= precedence(item))
			{
				postfix_exp[j] = x;
				j++;
				x = pop();
			}
			push(x);
			push(item);
		}
		else if(item == ')')
		{
			//printf("D \n");
			x = pop();
			while(x != '(')
			{
				postfix_exp[j] = x;
				j++;
				x = pop();
			}
		}
		else
		{
			break;
		}
		i++;


		item = infix_exp[i];
	}

	if(top>0)
	{
		printf("\nInvalid infix Expression.\n");
	}

	postfix_exp[j] = '\0';
	//puts(postfix_exp);

}

void main()
{
    char infix[SIZE], postfix[SIZE];
    printf("Enter a infix expression :- ");
    scanf("%s", infix);
    InfixToPostfix(infix,postfix);
    printf("Postfix is:- %s \n", postfix);
}
