#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include "stack.h"

int precedence(char symbol)
{
	if(symbol == '^')
	{
		return(3);
	}
	else if(symbol == '*' || symbol == '/')
	{
		return(2);
	}
	else if(symbol == '+' || symbol == '-')
	{
		return(1);
	}
	else
	{
		return(0);
	}
}
int is_operator(char symbol)
{
	if(symbol == '^' || symbol == '*' || symbol == '/' || symbol == '+' || symbol =='-')
	{
		return 1;
	}
	else if (symbol == '(' || symbol == ')')
	{
		return 2;
	}
	else
	{
		return 0;
	}
}
void InfixToPostfix(char infix_exp[], char postfix_exp[], char stack[],  int *top, int n)
{
    	int i, j,k,m;
	char item;
	char x;
	m = pushc(stack,top,'(',n);
	strcat(infix_exp,")");
	i=0;
	j=0;
	item=infix_exp[i];
	while (item != '\0')
	{
		//printf("item = %c \n ", item);

		if(item == '(')
		{
			m = pushc(stack,top,item,n);
		}
		else if(isdigit(item) || isalpha(item))
		{
			postfix_exp[j] = item;
			j++;
		}
		else if(is_operator(item) == 1)
		{	
			//k = precedence(item);
			//printf("%d",k);
			x = popc(stack,top);
			while(is_operator(x) == 1 && precedence(x)>= precedence(item))
			{
				postfix_exp[j] = x;
				j++;
				x = popc(stack,top);
			}
			m = pushc(stack,top,x,n);
			m = pushc(stack,top,item,n);
		}
		else if(item == ')')
		{
			x = popc(stack,top);
			while(x != '(')
			{
				postfix_exp[j] = x;
				j++;
				x = popc(stack,top);
			}
		}
		else
		{
			break;
		}
		i++;


		item = infix_exp[i];
	}

	postfix_exp[j] = '\0';

}

void main()
{
	int top, n;
	n = 100;
	char stack[n];
	top = 0;
	char infix[n], postfix[n];
	printf("Enter a infix expression :- ");
	scanf("%s", infix);
	InfixToPostfix(infix,postfix,stack, &top, n);
	printf("Postfix is:- %s \n", postfix);
	
}
