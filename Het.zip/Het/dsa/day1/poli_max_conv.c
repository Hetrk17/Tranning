#include<stdio.h>
#include<string.h>
#include <ctype.h>
void main()
{

	char s[100] = "21x3 +2x2y1 +3x1y2 +3y3 +1x1 +1y1 +";
	int array[100][100];
	int n,i,x,y,j,coff,mul,num,xpow,ypow;

	n =strlen(s);

	for(i=0;i<n;i++)
	{
		xpow = 0;
		ypow = 0;
		while(s[i] != '+')
		{
			mul = 1;
			if(isdigit(s[i]))
			{
				
				num = s[i] - '0';
				coff = num;
				i++;
				while(isdigit(s[i]))
				{
					num = s[i] - '0';
					coff = (coff*10) + (num);
					i++;
					
				}
			}
			
			if(s[i] == 'x')
			{	
				
				i++;
				xpow = 1;
				if(isdigit(s[i]))
				{
					xpow = s[i] - '0';
					i++;
						
				}
				if(s[i] == 'y')
				{
					i++;
					ypow = s[i] - '0';
					i++;
				}
			}
			else if(s[i] == 'y') 
			{
				
				i++;
				xpow = 0;
				if(isdigit(s[i]))
				{
					ypow = s[i] - '0';
					i++;
						
				}
				else
				{
					
					ypow = 1;
					i++;
				}
			}
			if(s[i] == ' ')
			{
				array[xpow][ypow] = coff;
				i++;
			}
		}
	}
	printf("\n");
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			printf("%d ", array[i][j]);
		}
		printf("\n");
	}

}

