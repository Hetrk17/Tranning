#include<stdio.h>

void main()
{
	int i,j,x[4][4],y[4][4],xpow,ypow,n,coff,ans[4][4];
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			ans[i][j] = 0;
		}
	}
	printf("How much elemnt in 1st:- ");
	scanf("%d", &n);
	
	for(i=0;i<n;i++)
	{
		printf("Enter power of x");
		scanf("%d", &xpow);
		printf("Enter power of y");
		scanf("%d", &ypow);
		printf("Enter a cofficent:- ");	
		scanf("%d", &coff);
		x[xpow][ypow] = coff;
	}
	printf("How much elemnt in 2st:- ");
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		printf("Enter power of x");
		scanf("%d", &xpow);
		printf("Enter power of y");
		scanf("%d", &ypow);
		printf("Enter a cofficent:- ");	
		scanf("%d", &coff);
		y[xpow][ypow] = coff;
	}
	for(i=0;i<4;i++)
	{
		for(j=0;j<4;j++)
		{
			ans[i][j] = x[i][j] + y[i][j];
		}
	}
	printf("%dx^3 + %dx^2y + %dxy^2 + %dy^3 + %dx + %dy", ans[3][0],ans[2][1],ans[1][2], ans[0][3],ans[1][0],ans[0][1]);
}
