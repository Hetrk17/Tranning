#include<stdio.h>

void main()
{
	int i,j,n,base,ans,row,col,choise;
	printf("Enter a base address:- ");
	scanf("%d", &base);
	printf("Enter a Element size:- ");
	scanf("%d", &n);
	printf("Enter a number of rows:- ");
	scanf("%d", &row);
	printf("Enter a number of column:- ");
	scanf("%d", &col);
	printf("Row major/column major(1/0):- ");
	scanf("%d", &choise);
	printf("Enter a Element index (i,j):- ");
	scanf("%d %d", &i, &j);
	if(choise)
	{
		ans = base + (n*(((i-1)*col) + (j-1)));
	}
	else
	{
		ans = base + (n*((i-1) + ((j-1)*row)));
	}
	printf("Adress is %d \n", ans);
}

