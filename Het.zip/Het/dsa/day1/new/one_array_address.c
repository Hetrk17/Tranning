#include<stdio.h>

void main()
{
	int i,n,base,ans;
	printf("Enter a base address:- ");
	scanf("%d", &base);
	printf("Enter a Element size:- ");
	scanf("%d", &n);
	printf("Enter a Element index:- ");
	scanf("%d", &i);
	ans = base + ((i-1)*n);
	printf("Adress is %d \n", ans);
}

