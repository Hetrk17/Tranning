#include <stdio.h>
#define MAX_LENGTH 10
#define LENGTH 2
int q[LENGTH][MAX_LENGTH];
int front=-1;
int rear=-1;
void enqueue(int,int);
void dequeue();
void display();


void main()
{
    printf("Enter \n 1 for enqueue operation\n2 for dequeue operation\n3 to exit\n");
    int choice,e,p;
    scanf("%d",&choice);

    while(choice!=3)
    {

    if(choice==1)
    {
        printf("Enter element to be enqueued ");
        scanf("%d",&e);
        printf("Enter priority of the element ");
        scanf("%d",&p);

        enqueue(e,p);
    }
    else if(choice==2)
    {
        dequeue();
    }
    printf("\nEnter choice again\n");
    scanf("%d",&choice);
    }
}

void enqueue(int e,int p)
{
    //For First element of queue
    if(front==-1 && rear==-1)
    {
        front++;
        rear++;
        q[0][rear]=e;
        q[1][rear]=p;
    }

    else if(rear==MAX_LENGTH-1)
    {
        printf("Queue is full");
        return;
    }
    else
    {
        rear++;
        q[0][rear]=e;
        q[1][rear]=p;
    }

    int i,j,x,min_idx;

    for (i = front; i <rear; i++)
    {
        // Find the minimum element in unsorted array
        min_idx = i;
        for (j = i+1; j <=rear; j++)
        {
         if (q[1][j] > q[1][min_idx])
          {

           min_idx = j;

        // Swap the found minimum element with the first element

            x=q[1][min_idx];
            q[1][min_idx]=q[1][i];
            q[1][i]=x;

            x=q[0][min_idx];
            q[0][min_idx]=q[0][i];
            q[0][i]=x;
          }
        }

    }


    display();
}

void dequeue()
{
    if(front==-1 & rear==-1)
    {
        printf("Queue is empty");
        return;
    }
    // only one element left so reset the queue
    else if(front==rear)
    {
        front=-1;
        rear=-1;
    }
    else
    {
        front++;
    }

    display();
}

void display()
{
    int i;
    printf("queue:    ");
    for(i=0;i<front;i++)
    {
        printf("* ");
    }
    for(i=front;i<=rear;i++)
    {
        printf("%d ",q[0][i]);
    }
    for(i=rear+1;i<MAX_LENGTH;i++)
    {
        printf("* ");
    }
    printf("\npriority: ");
    for(i=0;i<front;i++)
    {
        printf("* ");
    }
    for(i=front;i<=rear;i++)
    {
        printf("%d ",q[1][i]);
    }
    for(i=rear+1;i<MAX_LENGTH;i++)
    {
        printf("* ");
    }
}
