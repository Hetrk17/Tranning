#include <stdio.h>
#define LENGTH 5
int q[LENGTH];
int front=-1;
int rear=-1;
void enqueue(int);
void dequeuq();
void display();

void main()
{
    printf("Enter\n1 to enque\n2 to deque\n3 to exit\n");
    int c,e;
    scanf("%d",&c);

    while(c!=3)
    {
        if(c==1)
        {
            printf("Enter element to be enqueued ");

            scanf("%d",&e);
            enqueue(e);
        }
        else if(c==2)
        {
            dequeue();
        }
        printf("\nEnter choice again");
        scanf("%d",&c);
    }
}

void enqueue(int e)
{
    if(((front==0)&&(rear==LENGTH-1))||(front==rear+1))
    {
        printf("Queue overflow\n");
    }
    else
    {
       
        if(rear==-1)
        {
            rear++;
            front++;
        }
        
        else if(rear==LENGTH-1)
            rear=0;
        else
            rear++;
        q[rear]=e;
    }
    display();
}

void dequeue()
{
    if(front==-1)
    {
        printf("Queue underflow");
        return;
    }
    else
    {
        
        if(front==rear)
        {
        front=-1;
        rear=-1;
        }
        
        else if(front==LENGTH-1)
        {
            front=0;
        }
        else
        {
            q[front] = 0;
            front++;
        }
    }
    display();
}

void display()
{
    int i;
    printf("Queue:");
    for(i=0;i<LENGTH;i++)
    {
        printf("%d ",q[i]);
    }
}
