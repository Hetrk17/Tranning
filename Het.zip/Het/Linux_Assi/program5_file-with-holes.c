//Program to create a file with a 4K bytes free space.

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>

void main()
{
	int fd;
	char buff[4096] = "";
	struct stat st;

	fd = open("File_with_Holes", O_CREAT | O_WRONLY , 777);

	if(fd<0)
	{
		printf("File could not be opened or created\n");
		return;
	}

	write(fd, buff, 4096);

	//check size
	fstat(fd, &st);
	printf("\nFile with size = %lu (free space) successfully created.\n\n",(st.st_size));

	close(fd);
	
}
