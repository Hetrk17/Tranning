#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main()
{
	int fd1, fd2;
	char buff[100];
	int n_bytes;

	fd1 = open("main.txt", O_RDONLY, 777);
	fd2 = open("copied.txt", O_CREAT | O_WRONLY, 777);

	if(fd1<0 || fd2<0)
	{
		printf("One of the file can't be opened.\n");
		return 0;
	}

	n_bytes = read(fd1, buff, 100);

	write(fd2, buff, n_bytes);

	printf("\nThe file has been copied\n");
	
	close(fd1);
	close(fd2);

	return 0;
}
