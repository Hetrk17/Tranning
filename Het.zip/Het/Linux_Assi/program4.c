//This program implements all file operations - create, open, write, read, lseek, close
#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include <sys/stat.h>

void main()
{
	int fd = creat("newFile.txt", 777);

	if(fd<0)
	{
		printf("File is not created\n");
		return;
	}
	
	printf("\nFile create successfully.\n");

	fchmod(fd, S_IRWXU);	
	fd = open("newFile.txt", O_RDWR | O_CREAT, 777);

	if(fd<0)
	{
		printf("File is not opened or created");
		return;
	}

	printf("\nFile opened successfully.\n");

	char write_buf[50] = "This is the rendom data to be written!\n";
	char read_buf[50];

	int len;
	len = write(fd,write_buf,50);
	printf("\nData written to the file.\n");
	printf("Total Number of bytes written = %d",len);
	lseek(fd,0,SEEK_SET);
	printf("\n\nRepositioned to the start of the file for reading.");
	read(fd,read_buf,len);
	printf("\n\nThe data read from file is:\n%s\n",read_buf);
	close(fd);
}
