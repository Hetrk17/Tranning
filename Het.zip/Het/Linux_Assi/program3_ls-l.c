#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>

int main( )
{
	struct stat st;	
	int fd;
	
	stat("file.txt", &st);

	printf("\n--------Existing file--------\n\n");
	printf("File Information for 'file.txt' :\nType and Permissions: %u\n", st.st_mode);
	printf("Number of hard links: %lu\n", st.st_nlink);
	printf("User Id: %u\n", st.st_uid);
	printf("Group Id: %u\n", st.st_gid);
	printf("File size = %lu\n",(st.st_size));

	printf("\nFile inode = %lu \n", st.st_ino);
	printf("size disc of blocks = %lu \n",st.st_blksize);
	
	
	printf("\n\n--------Opened file--------\n\n");
	fd=open("original.txt", O_RDONLY);
 	fstat(fd, &st);

	printf("File Information for 'original.txt':\nType and Permissions: %u\n", st.st_mode);
	printf("Number of hard links: %lu\n", st.st_nlink);
	printf("User Id: %u\n", st.st_uid);
	printf("Group Id: %u\n", st.st_gid);
	printf("File size = %lu\n",(st.st_size));

	printf("\nFile inode = %lu \n", st.st_ino);
	printf("size disc of blocks = %lu \n",st.st_blksize);


	close(fd);
	return 0;
}
