#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
	int fd, len;
 	int x;
	char write_buf[4000];	
	fd = open("linux0011.txt",O_CREAT |O_RDWR, 0777);
	write(fd,write_buf,4000);
	close(fd);
}

