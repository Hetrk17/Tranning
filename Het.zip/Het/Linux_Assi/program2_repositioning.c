#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

void main()
{
	int fd;
	int pos;
	char read_buff1[200] = "";

	fd = open("file.txt", O_RDONLY, 777);

	if(fd<0)
		printf("\nFile could not be opened");

	pos = lseek(fd, 0, SEEK_CUR);
	printf("\nInitial Position of Current File Offset Position: %d", pos);
	printf("\n\n\tComplete data in the file is :");
	read(fd, read_buff1, 200);
	printf("%s",read_buff1);
	pos = lseek(fd, 0, SEEK_CUR);
	printf("\n\nCurrent Position after reading: %d", pos);
	printf("\n\t-10 offset from SEEK_END: ");
	pos = lseek(fd, -10, SEEK_END);
	printf("\n\nCurrent Position after repositioning: %d", pos);

	char read_buff2[200] = "";
	read(fd, read_buff2, 200);
	printf("\nData:\n");
	printf("%s",read_buff2);

	pos = lseek(fd, 0, SEEK_CUR);
	printf("\n\nCurrent Position after reading: %d", pos);
	printf("\n\t5 offset from SEEK_SET: ");
	pos = lseek(fd, 5, SEEK_SET);
	printf("\n\nCurrent Position after repositioning: %d", pos);

	char read_buff3[200] = "";
	read(fd, read_buff3, 10);
	printf("\nData (10 bytes): \n");
	printf("%s",read_buff3);

	pos = lseek(fd, 0, SEEK_CUR);
	printf("\n\nCurrent Position after reading: %d", pos);
	printf("\n\t5 offset from SEEK_CUR: ");
	pos = lseek(fd, 5, SEEK_CUR);
	printf("\n\nCurrent Position after repositioning: %d", pos);

	char read_buff4[200] = "";
	read(fd, read_buff4, 10);
	printf("\nData (10 bytes): \n");
	printf("%s",read_buff4);

	pos = lseek(fd, 0, SEEK_CUR);
	printf("\n\nCurrent Position after reading: %d", pos);
	printf("\n\t-10 offset from SEEK_CUR: ");
	pos = lseek(fd, -10, SEEK_CUR);
	printf("\n\nCurrent Position after repositioning: %d", pos);

	char read_buff5[200] = "";
	read(fd, read_buff5, 20);
	printf("\nData (20 bytes): \n");
	printf("%s",read_buff5);

	pos = lseek(fd, 0, SEEK_CUR);
	printf("\n\nCurrent Position after reading: %d", pos);
	printf("\n");

	close(fd);

}
