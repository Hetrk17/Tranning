#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("Can you see me [ONE]\n");
	
	execl("/bin/ls","ls",NULL);

	printf("Can you see me [TWO]\n");
}

