#include<stdio.h>
#include<unistd.h>
# include <sys/types.h>
# include <fcntl.h>

int main()
{	
	printf("I am going to execute an 'ls' program\n");
	execl("/bin/ls","ls","-lh",NULL);
	
	return 0;
}

