#include<fstream>
#include<iostream>
using namespace std;

class student
{
	public:
	     int roll; char name[25];float marks;
	     void getdata()
	     {
	     	cout << "Enter roll no and name" <<endl;
	     	cin>>roll>>name;
	     	cout<<"marks"<<endl;
	     	cin>>marks;
	     }
	     void Addrecode()
	     {
	     	fstream f;
	     	student stu;
	     	f.open("student.dat", ios::app | ios::binary);
	     	stu.getdata();
	     	f.write((char*)&stu, sizeof(stu));
	     	f.close();
	     }
	     void display()
	     {
	     	fstream f1;
	     	student s;
	     	f1.open("student.dat", ios::in | ios::binary);
	     	while(f1.read((char*)&s, sizeof(s)))
		{
	     		cout<<"Roll "<<s.roll << " Name "<< s.name << " Marks: " << s.marks <<endl;
	     	}
	     	f1.close();
	     }
};

int main()
{
	student s1;
	char ch='n';
	do
	{
		s1.Addrecode();
		cout<<"Add more?(y/n)"<<endl;
		cin>>ch;
	}while(ch=='y' || ch=='Y');
	cout<<"updated!!!"<<endl;
	
	student s2;
	s2.display();
	return 0;
}
