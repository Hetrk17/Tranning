#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<string.h>
#include<netinet/in.h>
#include <arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>



void main()
{
	char *serv_ip = "127.0.0.1";
	char msg[100] = "abcdefghijklmno";
	char buf[10000];
	int count = 0;
	int sockfd,ret_val,n;
	socklen_t addr_len;
	struct sockaddr_in servaddr,cliaddr;
	socklen_t clilen;
	sockfd = socket(AF_INET,SOCK_DGRAM,0);
	if(sockfd<0)
	{
		perror("error:");
		exit(1);
	}

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(8000);
	inet_pton(AF_INET, serv_ip, &servaddr.sin_addr);
	addr_len = sizeof(struct sockaddr_in);
	// send data to server socket, need not conncet to server socket
	do
	{
		printf("\n\n\n\n******************************************************************************\n\n");
		printf("Enter a massage:- ");
		scanf("%s", msg);
		ret_val = sendto(sockfd,msg,strlen(msg),0,(struct sockaddr *)&servaddr, addr_len);
		printf("retval of sendto = %d\n",ret_val);
		n = recvfrom(sockfd, buf, 10000, 0, (struct sockaddr *)&cliaddr, &clilen);
		printf("Received %d bytes\n", n);
		buf[n] = '\0';
		printf("Message from Server = %s\n\n", buf);
		count++;
		printf("%d Massage left", 5-count);
		printf("\n\n******************************************************************************\n\n\n\n");
		
	}while(count < 5);
	close(sockfd);
}
