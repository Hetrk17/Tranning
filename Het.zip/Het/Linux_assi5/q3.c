#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
int fds[2];

void main()
{
	int return_value,i,n;
	pid_t pid;

	char *buf1 = "abcdefghij";
	char *buf2 = "klmnopqrst";
	char buf[100];
	return_value = pipe(fds);
	if(return_value == -1)
	{
		perror("pipe");
		exit(1);
	}
	pid = fork();
	if(pid==0)
	{
		printf("\n*************************************************************\n");
		close(fds[0]);
		printf("Data in buffer1 is %s\n", buf1);
		write(fds[1],buf1,20);
		printf("Buffer1 data writen in pipe\n\n");
		printf("Data in buffer2 is %s\n", buf2);
		write(fds[1],buf2,20);
		printf("Buffer2 data writen in pipe\n\n");
		printf("End of perent\n");
		printf("*************************************************************\n\n");
	}
	else
	{
		close(fds[1]);
		n = read(fds[0],buf,40);
		printf("\n\n*************************************************************\n");
		printf(" No of chars read = %d\n",n);
		for(i=0;i<n;i++)
		{
			if(buf[i]>='a' && buf[i]<= 'z')
			buf[i] = buf[i] -32;			
		}
		for(i=0;i<n;i++)
		{
			printf("%c", buf[i]);
		}
		printf("\n*************************************************************\n\n");
		
	}
	
	wait(0);
}
