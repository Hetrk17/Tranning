#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>
#include<sys/ipc.h>
#include<sys/msg.h>
struct msgbuf
{
	long mtype;
	char data[512];
};

int main()
{
	struct msgbuf v;
	struct msqid_ds buf;
	char msg1[10] = "0123456789";
	char msg2[10] = "ABCDEFGHIG";
	int id;
	
	id = msgget(60,IPC_CREAT|0644);
	printf("\n*************************************************************\n");
	printf("Id of the Massage queue = %d\n", id);
	v.mtype= 71;
	strcpy(v.data, msg1);
	msgsnd(id,&v,strlen(v.data)+1,0);
	printf("Massage 1 is send in Massage queue \n");
	printf("*************************************************************\n\n");
	
	
	

	msgctl(id,IPC_STAT,&buf);
	printf("\n*************************************************************\n");
	printf("Here are the details of the queue\n");
	printf("No of Massage in queue %hi\n",buf.msg_qnum);
	printf("Max no of bytes in queue %hi\n",buf.msg_qbytes);
	printf("Current no of bytes in queue %hi\n",buf.msg_cbytes);
	printf("*************************************************************\n\n");
	
	
	
	printf("\n*************************************************************\n");
	printf("Id of the Massage queue = %d\n", id);
	v.mtype= 72;
	strcpy(v.data, msg2);
	msgsnd(id,&v,strlen(v.data)+1,0);
	printf("Massage 2 is send in Massage queue \n\n");
	printf("*************************************************************\n\n");
	
	
	msgctl(id,IPC_STAT,&buf);
	printf("\n*************************************************************\n");
	printf("Here are the details of the queue\n");
	printf("No of Massage in queue %hi\n",buf.msg_qnum);
	printf("Max no of bytes in queue %hi\n",buf.msg_qbytes);
	printf("Current no of bytes in queue %hi\n",buf.msg_cbytes);
	printf("*************************************************************\n\n");
	
	
	printf("\n*************************************************************\n");
	printf("Id of the Massage queue = %d\n", id);
	msgrcv(id,&v,sizeof(v),71,0);
	printf("Data %s\n",v.data);
	printf("Massage 1 is read in Massage queue \n\n");
	printf("*************************************************************\n\n");
	
		msgctl(id,IPC_STAT,&buf);
	printf("\n*************************************************************\n");
	printf("Here are the details of the queue\n");
	printf("No of Massage in queue %hi\n",buf.msg_qnum);
	printf("Max no of bytes in queue %hi\n",buf.msg_qbytes);
	printf("Current no of bytes in queue %hi\n",buf.msg_cbytes);
	printf("*************************************************************\n\n");
	
	printf("\n*************************************************************\n");
	printf("Id of the Massage queue = %d\n", id);
	msgrcv(id,&v,sizeof(v),72,0);
	printf("Data %s\n",v.data);
	printf("Massage 2 is read in Massage queue \n\n");
	printf("*************************************************************\n\n");
	
		msgctl(id,IPC_STAT,&buf);
	printf("\n*************************************************************\n");
	printf("Here are the details of the queue\n");
	printf("No of Massage in queue %hi\n",buf.msg_qnum);
	printf("Max no of bytes in queue %hi\n",buf.msg_qbytes);
	printf("Current no of bytes in queue %hi\n",buf.msg_cbytes);
	printf("*************************************************************\n\n");
	return 0;
}
