#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#include<sys/shm.h>

int main()
{
	char *Addr;
	int id;
	
	id = shmget(48,250,IPC_CREAT|0644);
	if(id<0)
	{
		perror("shmget\n");
		return 0;
	}
	printf("\n*************************************************************\n");
	printf("Id of the Shered memeory = %d\n\n", id);
	Addr = shmat(id,0,0);
	printf("Address of the Shered memeory = %p\n", Addr);
	printf("*************************************************************\n\n");
	return 0;
}

