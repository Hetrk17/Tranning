#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
struct user
{
	int bal;
	int pin;
	char id;
};
int Withdrow(int bale, int money)
{
	int ans;
	ans = bale - money;
	if(ans<0)
	{
		ans = bale;
		printf("You can not Withdrow %d \n", money);
	}
	else
	{
		printf("Withdrow %d suscessfully \n", money);
	} 
	return ans;
}
int Deposite(int bale, int money)
{
	int ans;
	ans = bale + money;
	printf("Deposite %d suscessfully \n", money); 
	return ans;
}
void main()
{
	int num,temp,up,low,i,index,flagid,chance,upin,wid;
	struct user u1;
	int pin[10] = {1234,5678,9102,3456,7890};
	char id[10] = {'a','c','d','m','n'};
	char ch;
	chance = 2;
	flagid = 0;
	up =1000;
	low =100000;
	srand(time(0)); 
	u1.bal = (low+1+rand()%(up+low-1));
	printf("Enter your id:- ");
	scanf("%c", &ch);
	for(i=0;i<5;i++)
	{
		if(ch == id[i])
		{
			u1.id = id[i];
			flagid = 1;
			index = i;
			break;
		}
	}
	if(flagid == 1)
	{
		jmp:
		u1.pin = pin[index];
		while(chance !=0)
		{
			printf("Please Enter a Pin:- ");
			scanf("%d", &upin);
			if(upin == u1.pin)
			{
				printf("1:- Check belence \n");
				printf("2:- Withdrow Case \n");
				printf("3:- Deposite a case \n");
				printf("4:- Quit \n");
				do
				{
					printf("Enter a your choise:- ");
					scanf("%d", &temp);
					if(temp == 1)
					{
						printf("Your u1.bal is %d\n", u1.bal);
					}
					else if(temp == 2)
					{
						printf("Enter Withdrow amount:- ");
						scanf("%d", &wid);
						u1.bal = Withdrow(u1.bal,wid);
					}
					else if(temp == 3)
					{
						printf("Enter Deposite amount:- ");
						scanf("%d", &wid);
						u1.bal = Deposite(u1.bal,wid);
					}
					else if(temp == 4) 
					{
						printf("Thanks for Visit \n");
					}
				}while(temp!=4);
				chance = 0;	
			}
			else
			{
				printf("Wrong Pin!! Enter a correct Pin \n");
				chance--;
				if(chance == 0)
				{
					printf("Your Card is block \n");
				}
			}
		}
	}
	else
	{
		printf("Please Rasister your Id. \n");
		printf("Please enter ID:- ");
		scanf("%s", &id[6]);
		printf("Please enter PIN:- ");
		scanf("%d", &pin[6]);
		goto jmp;
	}
	
}
