#include<stdio.h>

void main()
{
	int a=10, *p, b=20, *q,sum;
	p = &a;
	q = &b;
	printf("Value of A:- %d , B:- %d \n",*p,*q);
	sum = (*p)+(*q);
	printf("Sum of A and B is %d \n", sum);

}
