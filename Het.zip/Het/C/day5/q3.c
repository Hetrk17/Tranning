#include<stdio.h>
void swap(int *ap, int *bp)
{
	int temp;
	temp = *ap;
	*ap = *bp;
	*bp = temp;
}
void main()
{
	int a=10, b =20;
	printf("Value of A:- %d , B:- %d \n",a,b);
	swap(&a,&b);
	printf("After a function call \n");
	printf("Value of A:- %d , B:- %d \n",a,b);
}
