#include<stdio.h>

void main()
{
	int a=10, *p;
	p = &a;
	printf("Addres of A is %p \n", p);

}
