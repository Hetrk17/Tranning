#include<stdio.h>

void main()
{
	int *p,i,j;
	int temp;
	int a[10] = {99,3,5,2,9,10,25,90,6,1};
	printf("Befor shorting \n");
	for(i=0;i<10;i++)
	{
		printf("%d ", a[i]);
	}
	p = &a[0];
	for(i=0;i<10;i++)
	{
		for(j= i +1; j<10; j++)
		{
			if(*(p+j)<*(p+i))
			{
				
				temp = *(p+j);
				*(p+j) = *(p+i);
				*(p+i) = temp;
			}
		}
	}
	printf("\n After shorting \n");
	for(i=0;i<10;i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");

}
