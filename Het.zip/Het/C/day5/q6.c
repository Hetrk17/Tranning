#include<stdio.h>
void main()
{
	int *p,sum,i;
	sum = 0;
	int a[10];
	for(i=0;i<10;i++)
	{
		a[i] = i+1;
	}
	p = &a[0];
	for(i=0;i<10;i++)
	{
		sum = sum + *(p+i);
	}
	printf("Sum of arrey is %d \n", sum);

}
