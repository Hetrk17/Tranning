#include<stdio.h>

void main()
{
	int a=10, *p;
	p = &a;
	printf("Value of A:- %d , *p:- %d \n",a,*p);
	printf("Addres of A is %p \n", p);

}
