#include<stdio.h>

void main()
{
	int a=10, *p, **q;
	p = &a;
	q = &p;
	printf("Value of A:- %d , *p:- %d, **q:- %d \n",a,*p,**q);
	printf("Addres of A is %p", p);

}
