#include<stdio.h>

int sum(int a, int b)
{
	return (a+b);
}

int mul(int a, int b)
{
	return (a*b);
}

void main()
{
	int a,b;
	a = 10;
	b = 20;
	printf("Sum = %d \n", sum(a,b));
	printf("Mul = %d \n", mul(a,b));
}
