#include<stdio.h>
#include<stdlib.h>

void main()
{
	int *fp,n,m,i;
	printf("How many Members? \n");
	scanf("%d", &n);
	fp = (int *)calloc(n,sizeof(int));
	printf("Addres is %p, ", fp);
	for(i=0; i<n; i++)
	{
		printf("Enter %d age:- ", i);
		scanf("%d", (fp+i));
	}
}
