#include<stdio.h>
#include<stdlib.h>

void main()
{
	int *fp;
	fp = (int *)malloc(sizeof(int));
	printf("Addres is %p, ", fp);
	printf("Value is %d \n", *fp);
}
