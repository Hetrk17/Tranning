#include<stdio.h>

int intrest(int p, int n, int r)
{
	return (p*n*r/100);
}

void main()
{
	int p,n,r;
	printf("Principal amount:- ");
	scanf("%d", &p);
	printf("Rate:- ");
	scanf("%d", &r);
	printf("Time:- ");
	scanf("%d", &n);
	printf("Simple intrest is %d \n", intrest(p,n,r));
}
