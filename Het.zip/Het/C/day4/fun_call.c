#include<stdio.h>

extern void addition(int a, int b);

void main()
{
	extern int p;
	int x=2, y=3;
	printf("Value of p is %d \n", p);
	addition(x,y);
}
