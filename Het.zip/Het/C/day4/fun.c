#include<stdio.h>

int p = 10;
void addition(int a, int b)
{
	printf("%d + %d = %d \n", a,b,a+b);
}
/*
void main()
{

	int x=2, y=3;
	p = 0;
	printf("Value of p is %d \n", p);
}
*/
