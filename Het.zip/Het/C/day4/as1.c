#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
int Withdrow(int balance, int money)
{
	int ans;
	ans = balance - money;
	if(ans<0)
	{
		ans = balance;
		printf("You can not Withdrow %d \n", money);
	}
	else
	{
		printf("Withdrow %d suscessfully \n", money);
	} 
	return ans;
}
int Deposite(int balance, int money)
{
	int ans;
	ans = balance + money;
	printf("Deposite %d suscessfully \n", money); 
	return ans;
}
void main()
{
	int num,temp,up,low,i,index,flagid,chance,upin,wid,balance;
	int bal[5];
	int pin[5] = {1234,5678,9102,3456,7890};
	char id[5] = {'a','c','d','m','n'};
	char ch;
	chance = 2;
	flagid = 0;
	up =1000;
	low =100000;
	for(i=0;i<5;i++)
	{
		srand(time(0)+i); 
		bal[i] = (low+1+rand()%(up+low-1));
	}
	printf("Enter your id:- ");
	scanf("%c", &ch);
	for(i=0;i<5;i++)
	{
		if(ch == id[i])
		{
			flagid = 1;
			index = i;
			break;
		}
	}
	if(flagid == 1)
	{
		balance = bal[index];
		while(chance !=0)
		{
			printf("Please Enter a Pin:- ");
			scanf("%d", &upin);
			if(upin == pin[index])
			{
				printf("1:- Check belence \n");
				printf("2:- Withdrow Case \n");
				printf("3:- Deposite a case \n");
				printf("4:- Quit \n");
				do
				{
					printf("Enter a your choise:- ");
					scanf("%d", &temp);
					if(temp == 1)
					{
						printf("Your balance is %d\n", balance);
					}
					else if(temp == 2)
					{
						printf("Enter Withdrow amount:- ");
						scanf("%d", &wid);
						balance = Withdrow(balance,wid);
					}
					else if(temp == 3)
					{
						printf("Enter Deposite amount:- ");
						scanf("%d", &wid);
						balance = Deposite(balance,wid);
					}
					else if(temp == 4) 
					{
						printf("Thanks for Visit \n");
					}
				}while(temp!=4);
				chance = 0;	
			}
			else
			{
				printf("Wrong Pin!! Enter a correct Pin \n");
				chance--;
				if(chance == 0)
				{
					printf("Your Card is block \n");
				}
			}
		}
	}
	else
	{
		printf("Please enter a valide Id. \n");
	}
	
}
