#include<stdio.h>

int add(int m[11], int n)
{
	int i,sum;
	sum = 0;
	for(i=0;i<n;i++)
	{	
		sum = sum + m[i];
	}
	return sum;
}

void main()
{
	int a[11] = {1,2,3,4,5,6,7,8,9,10};
	int n;
	printf("How much number do you want to add:- ");
	scanf("%d", &n);
	printf("Simple intrest is %d \n", add(a,n));
}
