#include<stdio.h>

void add(int a, int b)
{
	printf("%d + %d = %d \n", a, b,(a+b));
}

void main()
{
	int a,b;
	printf("A:- ");
	scanf("%d", &a);
	printf("B:- ");
	scanf("%d", &b);
	add(a,b);
	printf("Thanks \n");
}
