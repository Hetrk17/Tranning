#include<stdio.h>
int a, b;
void swap()
{
	int temp;
	temp = a;
	a = b;
	b = temp;
}

void main()
{
	printf("A:- ");
	scanf("%d", &a);
	printf("B:- ");
	scanf("%d", &b);
	swap();
	printf("After function call \n");
	printf("A:- %d \n", a);
	printf("B:- %d \n", b);
}
