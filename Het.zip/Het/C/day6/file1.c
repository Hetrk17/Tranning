#include<stdio.h>


void main()
{
	FILE *fp;
	char str[50];
	char c;
	fp = fopen("Hello.txt","w");
	fprintf(fp,"Hello, How are you?\n");
	fclose(fp);
	fp = fopen("Hello.txt","r");
	do{
		c = getc(fp);
		printf("%c", c);
	}while(c!=EOF);
	fclose(fp);
}
