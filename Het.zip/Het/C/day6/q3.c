#include <stdio.h>
#include <string.h>
void main() {
	char str[50],c[50],rev[50];
	FILE *fptr;
	int n,i,j;
	fptr=(fopen("q3file.txt","w"));
	printf("Enter name: ");
	scanf("%s",str);
	fprintf(fptr,"%s ",str);
	fclose(fptr);
	fptr=(fopen("q3file.txt","r"));
	fscanf(fptr, "%s", c);
    	printf("Data from the file:\n%s \n ", c);
	n = strlen(c);
	j = n-1;
	for(i=0;i<n;i++)
	{
		rev[i] = c[j];
		j--;
	}
	puts(rev);
    	fclose(fptr);
}
