#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
#include<string.h>
struct student
{
	int id;
	char name[20];
	float cpi;
	int backlog;
}s1;
union book
{
	char title[20];
	char auther[20];
	int pages;
	float price;
}u1;
void main()
{
	s1.id = 1;
	strcpy(s1.name,"Het");
	s1.cpi = 7.8;
	s1.backlog = 0;
	printf("information is ");
	
}
