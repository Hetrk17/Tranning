#include<stdio.h>


void main()
{
	FILE *fp,*fpe,*fpo;
	int i,c,q,a[50],j;
	fp = fopen("Q2file.txt","w");
	for(i=0;i<10;i++)
	{
		fscanf(fp,"%d",&q);
		putc(',',fp);
	}
	fclose(fp);
	char buff[1024];
    	FILE *f = fopen("Q2file.txt", "r");
    	fgets(buff, 1024, f);
    	printf("String read: %s\n", buff);
    	fclose(f);
	fpe = fopen("Q2even.txt","w");
	fpo = fopen("Q2odd.txt","w");
	j = 0;
	for(i=0; buff[i] != '\0' ; i++)
	{
		if(buff[i] == ',')
		{	
			j++;
		}
		else
		{
			a[j] = buff[i]-48;
		}
	}
	for(i=0;i<10;i++)
	{
		q = a[j]+48;
		if(a[j]%2==0)
		{
			putc(q,fpe);
			putc(',',fpe);
		}
		else
		{
			putc(q,fpo);
			putc(',',fpo);
		}
	}
	fclose(fpe);
	fclose(fpo);
}
