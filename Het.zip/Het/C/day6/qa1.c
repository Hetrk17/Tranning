#include<stdio.h>


void main()
{
	FILE *fp,*fpe,*fpo;
	int i,c,q,a[50],j;
	char buff[50];
	fp = fopen("Q2file.txt","w");
	for(i=0;i<10;i++)
	{
		q = 48+i;
		putc(q,fp);
		putc(',',fp);
	}
	fclose(fp);
	printf("*");
	fp = fopen("Q2file.txt","r");
	fpe = fopen("Q2even.txt","w");
	fpo = fopen("Q2odd.txt","w");
	printf("*");
	fgets(buff,1024,fp);
	printf("%s", buff);
	for(i=0; buff[i] != '\0' ; i++)
	{
		if(buff[i] == ',')
		{	
			j++;
		}
		else
		{
			a[j] = buff[i]-48;
		}
	}
	for(i=0;i<10;i++)
	{
		q = a[j]+48;
		if(q%2==0)
		{
			putc(q,fpe);
			putc(',',fpe);
		}
		else
		{
			putc(q,fpo);
			putc(',',fpo);
		}
	}
	fclose(fpe);
	fclose(fpo);
	fclose(fp);
}
