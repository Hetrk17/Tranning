#include<stdio.h>
void main()
{
	char str[50],ch1,ch2;
	FILE *f1, *f2;
	int flag;
	flag = 0;
	f1=(fopen("file1.txt","w"));
	f2=(fopen("file2.txt","w"));
	char f1data[50] = "Hi, How are you ";
	char f2data[50] = "Hi, How are you ";
	fputs(f1data,f1);
	fputs(f2data,f2);
	fclose(f1);
	fclose(f2);
	
	f1=(fopen("file1.txt","r"));
	f2=(fopen("file2.txt","r"));
	ch1 = getc(f1);
        ch2 = getc(f2);
	

        while ((ch1 != EOF) && (ch2 != EOF) && (ch1 == ch2)) 
	{
       		ch1 = getc(f1);
       	       	ch2 = getc(f2);
        }

        if (ch1 == ch2)
		printf("Files are identical \n");
	else if (ch1 != ch2)
		printf("Files are Not identical \n");

	fclose(f1);
	fclose(f2);
}
