#include<stdio.h>

int main()
{
    FILE *f1,*f2,*f3;
    int number,i, n=10,q;
    f1 = fopen("DATA","w");
  
    for(i=0;i<n;i++)
    {
        putw(i,f1);
    }
    fclose(f1);

    f1 = fopen("DATA","r");
    f2 = fopen("ODD","w");
    f3 = fopen("EVEN","w");

    while((number = getw(f1)) != EOF)
    {
	q = number+48;
        if(number%2==0)
	   {
	    putc(q,f3);
	    putc(',',f3);
	    putc(' ',f3);
	   }
	else
	   {
	    putc(q,f2);
	    putc(',',f2);
	    putc(' ',f2);
	   }
    }

    fclose(f1);
    fclose(f2);
    fclose(f3);

    return 0;
}
