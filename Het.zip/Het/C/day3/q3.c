#include<stdio.h>

void main()
{
	int i,num;
	printf("Enter number of element:- ");
	scanf("%d", &num);
	int a[num];
	printf("Enter elements of array:- ");
	for(i=0;i<num;i++)
	{
		scanf("%d", &a[i]);
	}
	printf("array is \n");
	for(i=0;i<num;i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
	printf("Revrse array is \n");
	for(i=(num-1);i>=0;i--)
	{
		printf("%d ", a[i]);
	}
	
	printf("\n");

}
