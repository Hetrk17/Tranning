#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
void main()
{
	int sum,ans,c,uans,num1,num2,low,upper;
	c =5;
	low =1;
	upper =10;
	do
	{
		srand(time(0));
		num1 = (low+(rand()%(upper-low+1)));
		srand(time(0)+1); 
		num2 = (low+(rand()%(upper-low+1)));
		ans = num1 + num2; 
		printf("Do:- %d + %d = ", num1,num2);
		scanf("%d", &uans);
		if(ans == uans)
			{
				printf("Very Good!! \n");
				low = low*10;
				upper = upper*10;
			}
		else
			{
				printf("Wrong ans!! \n");
				c--;
				printf("Chance left:- %d \n",c);
			}
		
	}while(c!=0);
}
