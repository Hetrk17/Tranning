#include<stdio.h>

void main()
{
	int i,num,even,odd;
	printf("Enter number of element:- ");
	scanf("%d", &num);
	int a[num];
	printf("Enter elements of array:- ");
	for(i=0;i<num;i++)
	{
		scanf("%d", &a[i]);
	}
	even = 0;
	odd = 0;
	for(i=0;i<num;i++)
	{
		if((a[i]%2)==0)
		{
			even++;
		}
		else
		{
			odd++;
		}
	}
	printf("Even elements are %d \n", even);
	printf("Odd elements are %d \n", odd);
	printf("\n");

}
