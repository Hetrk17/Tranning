#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
void main()
{
	int num,temp,ch;
	srand(time(0)); 
	num = (1+rand()%100);
	printf("%d \n" ,num);
	do
	{
		printf("Enter a number:- ");
		scanf("%d", &temp);
		if(temp<num)
		{
			printf("Enter a lowwer number \n");
		}
		else if(temp>num)
		{
			printf("Enter a higher number \n");
		}
		else
		{
			printf("congratulations!! you won a game \n");
			break;
		}
		printf("Do you wont to continue?(1/0):- ");
		scanf("%d", &ch);
	}while(ch==1);
}
