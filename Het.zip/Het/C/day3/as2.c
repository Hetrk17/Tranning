#include<stdio.h>
#include <stdlib.h>  
#include <time.h> 
void main()
{
	int sum,ans,c,uans;
	int num[5] = {0,0,0,0,0};
	c =5;
	srand(time(0)); 
	num[0] = (1+rand()%100);
	srand(time(0)+1); 
	num[1] = (1+rand()%100);
	do
	{
		ans = num[0] + num[1] + num[2] + num[3] + num[4];
		if(num[2]==0)
		{
			ans = num[0] + num[1];
			printf("Do:- %d + %d = ", num[0],num[1]);
			scanf("%d", &uans);
			if(ans == uans)
			{
				printf("Very Good!! \n");
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				num[3] = 0;
				num[4] = 0;
			}
			else
			{
				printf("Wrong ans!! \n");
				c--;
				printf("Chance left:- %d \n",c);
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				num[2] = 0;
				num[3] = 0;
				num[4] = 0;
			}
		}
		if(num[3]==0)
		{
			printf("Do:- %d + %d + %d = ", num[0],num[1],num[2]);
			scanf("%d", &uans);
			ans = num[0] + num[1] + num[2];
			if(ans == uans)
			{
				printf("Very Good!! \n");
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				srand(time(0)+3); 
				num[3] = (1+rand()%100);
				num[4] = 0;
			}
			else
			{
				printf("Wrong ans!! \n");
				c--;
				printf("Chance left:- %d \n",c);
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				num[3] = 0;
				num[4] = 0;
			}
		}
		if(num[4]==0)
		{
			printf("Do:- %d + %d + %d + %d = ", num[0],num[1],num[2],num[3]);
			scanf("%d", &uans);
			ans = num[0] + num[1] + num[2] + num[3];
			if(ans == uans)
			{
				printf("Very Good!! \n");
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				srand(time(0)+3); 
				num[3] = (1+rand()%100);
				srand(time(0)+4); 
				num[4] = (1+rand()%100);
			}
			else
			{
				printf("Wrong ans!! \n");
				c--;
				printf("Chance left:- %d \n",c);
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				srand(time(0)+3); 
				num[3] = (1+rand()%100);
				num[4] = 0;
				
			}
		}
		else
		{
			printf("Do:- %d + %d + %d + %d + %d = ", num[0],num[1],num[2],num[3],num[4]);
			scanf("%d", &uans);
			ans = num[0] + num[1] + num[2] + num[3] + num[4];
			if(ans == uans)
			{
				printf("Very Good!! \n");
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				srand(time(0)+3); 
				num[3] = (1+rand()%100);
				srand(time(0)+4); 
				num[4] = (1+rand()%100);
			}
			else
			{
				printf("Wrong ans!! \n");
				c--;
				printf("Chance left:- %d \n",c);
				srand(time(0)); 
				num[0] = (1+rand()%100);
				srand(time(0)+1); 
				num[1] = (1+rand()%100);
				srand(time(0)+2); 
				num[2] = (1+rand()%100);
				srand(time(0)+3); 
				num[3] = (1+rand()%100);
				srand(time(0)+4); 
				num[4] = (1+rand()%100);
				
			}
		}

		
	}while(c!=0);
}
