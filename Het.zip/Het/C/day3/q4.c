#include<stdio.h>

void main()
{
	int i,row,col,j,positive,negative,zero;
	printf("Enter number rows of metrix:- ");
	scanf("%d", &row);
	printf("Enter number colome of metrix:- ");
	scanf("%d", &col);
	int a[row][col];
	positive =0;
	negative =0;
	zero = 0;
	printf("Enter elemrnt for A metrix \n ");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				printf("Enter %dx%d element:- ",i+1,j+1);
				scanf("%d", &a[i][j]);
			}
	}
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				if(a[i][j]>0)
				{
					positive++;
				}
				else if(a[i][j]<0)
				{
					negative++;
				}
				else
				{
					zero++;
				}

			}
	}
	printf("Positive elements are %d \n", positive);
	printf("Negetive elements are %d \n", negative);
	printf("Zero elements are %d \n", zero);
}
