#include<stdio.h>

void main()
{
	int id,newmarks;
	int marks[5];
	printf("Enter your ID:- ");
	scanf("%d", &id);
	printf("Enter your marks:- ");
	scanf("%d", &newmarks);
	marks[id] = newmarks;
	printf("updeted marks is %d \n", marks[id]);
}
