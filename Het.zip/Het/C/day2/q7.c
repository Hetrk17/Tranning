#include<stdio.h>

void main()
{
	int i,row,col,j,maxa,maxb,p,q,r,s,deter,sign;
	sign = 1;
	deter = 0;
	printf("Enter number rows of metrix:- ");
	scanf("%d", &row);
	printf("Enter number colome of metrix:- ");
	scanf("%d", &col);
	int a[row][col];
	int temp[row-1][col-1];
	int mul[row][col];
	printf("Enter elemrnt for A metrix \n ");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				printf("Enter %dx%d element:- ",i+1,j+1);
				scanf("%d", &a[i][j]);
			}
	}
	
	for(i=0; i<row;i++)
	{
		p = 0;
		q = 0;
		for(j=0; j<col; j++)
		{
			r = 0;
			s = 0;
			printf("(i,j) = (%d, %d)", i,j);
			printf("\n");
		
			for(p=0; p<3; p++)
			{
				if(p!=i)
				{
					s = 0; 
					for(q=0; q<3; q++)
					{
						if(q!=j)
						{
							temp[r][s] = a[p][q];
							printf("(p,q)=(%d, %d) ", p,q);
							s++;
						}
					}
					r++;
					printf("\n");
				}
				
			}
			printf("\n");
			deter = deter + (sign*a[i][j]*((temp[0][0]*temp[1][1]) - (temp[0][1]*temp[1][0])));
			sign = sign*(-1);
		}
		
			
	}
	printf("determent of metrix a is %d \n", deter/3);	
}
