#include<stdio.h>

void main()
{
	int i,temp,flag;
	flag = 0;
	int marks[10] = {3,6,7,8,1,8,5,8,9,3};
	printf("Enter a number:- ");
	scanf("%d", &temp);
	for(i=0; i<10;i++)
	{
		if(temp == marks[i])
		{
			printf("index is %d \n", i);
			flag = 1;
			break;
		}
	}
	if(flag == 0)
	{
		printf("%d is not avelable \n", temp);
	}
}
