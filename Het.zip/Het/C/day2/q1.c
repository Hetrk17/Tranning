#include<stdio.h>
void main()
{
	int num,temp,i,flag;
	flag = 0; 
	printf("Enter the number:- ");
	scanf("%d", &num);
	temp = num/2;
	for(i=2;i<=temp;i++)
	{
		if(num%i==0)
		{
			printf("%d is not prime number \n",num);
			flag = 1;
			break;
		}
	}
	if(flag==0)
	{
		printf("%d is prime number \n",num);
	}
}

