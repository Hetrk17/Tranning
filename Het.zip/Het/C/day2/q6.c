#include<stdio.h>

void main()
{
	int i,row,col,j,maxa,maxb,k;
	printf("Enter number rows of metrix:- ");
	scanf("%d", &row);
	printf("Enter number colome of metrix:- ");
	scanf("%d", &col);
	int a[row][col];
	int b[row][col];
	int mul[row][col];
	printf("Enter elemrnt for A metrix \n ");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				printf("Enter %dx%d element:- ",i+1,j+1);
				scanf("%d", &a[i][j]);
			}
	}
	printf("Enter elemrnt for B metrix \n");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				printf("Enter %dx%d element:- ",i+1,j+1);
				scanf("%d", &b[i][j]);
			}
	}
	maxa = a[0][0];
	maxb = b[0][0];
	printf("sum of metrix is \n");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
			{
				printf("%d ", a[i][j] + b[i][j]);
				if(maxa<a[i][j])
				{
					maxa = a[i][j];
				}
				if(maxb<b[i][j])
				{
					maxb = b[i][j];
				}
			}
		printf("\n");
	}
	printf("multiplicastion of metrix is \n");
	for(i=0; i<row;i++)
	{
		for(j=0; j<col; j++)
		{
			mul[i][j] = 0;
			for(k=0;k<col;k++)
			{
				mul[i][j] = mul[i][j] + a[i][j]*b[k][j]; 	
			}
			printf("%d ", mul[i][j]);
		}
		printf("\n");
			
	}
	printf("Maximum of metrix a is %d \n", maxa);
	printf("Maximum of metrix b is %d \n", maxb);	
}
