#include<stdio.h>

void main()
{
	float price[5] = {29.5,45.0,49.0,95.5,68.5};
	int id1,id2,id3,con1,con2,con3;
	float sum;
	printf("Enter the first details:- ");
	scanf("%d %d", &id1, &con1);
	printf("Enter the second details:- ");
	scanf("%d %d", &id2, &con2);
	printf("Enter the third details:- ");
	scanf("%d %d", &id3, &con3);
	sum = 0;
	sum = (price[id1-1]*con1) + (price[id2-1]*con2) + (price[id3-1]*con3);
	printf("Cost is %f \n", sum);
	
}
