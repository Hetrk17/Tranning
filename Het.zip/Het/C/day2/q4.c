#include<stdio.h>

void main()
{
	int i,min;
	int marks[10] = {3,6,7,8,1,8,5,8,9,3};
	min = marks[0];
	for(i=1; i<10;i++)
	{
		if(min>marks[i])
		{
			min = marks[i];
		}
	}
	printf("Minimum mark is %d \n", min);
}
