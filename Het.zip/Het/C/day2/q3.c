#include<stdio.h>

void main()
{
	int i,sum;
	int marks[10] = {3,6,7,8,9,8,5,8,9,3};
	sum = 0;
	for(i=0; i<10;i++)
	{
		sum = sum + marks[i];
	}
	printf("Total marks is %d \n", sum);
}
