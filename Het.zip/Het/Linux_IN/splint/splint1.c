#include<stdio.h>
int main()
{
	int i;
	printf("i=%d\n", i);
	return 0;
}
