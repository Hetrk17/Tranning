#include<stdio.h>
int main()
{
	int i=25;
	if(i=25)
		printf("i=%d\n", i);
	return 0;
}
