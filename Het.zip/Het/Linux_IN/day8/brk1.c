#include<stdio.h>
#include<unistd.h>

void main()
{
	long int page_size = sysconf(_SC_PAGESIZE);
	printf("Page size is :- %ld \n", page_size);
	
	void* c1 = sbrk(0);
	printf("Program break address: %p\n", c1);
	printf("sizeof char: %lu", sizeof(char));
	c1 = (void*)((char*)c1+9);
	printf("c1: %p\n",c1);
	//sbrk(9);
	void* c2 = sbrk(0);
	printf("Program break address: %p\n", c2);
}
