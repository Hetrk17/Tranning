#include <stdio.h>
#include <string.h>

int main()
{
	const char buf1[10];
	const char buf2[10];
	int ret;
	
	memcpy(buf1,"madam",5);
	memcpy(buf2,"madam",5);
	
	ret = memcmp(buf1,buf2,5);
	if(ret > 0)
	{
		printf("Buf1 is grater than buf2 %d\n", ret);
	}
	else if(ret < 0)
	{
		printf("Buf1 is less than buf2 %d \n",ret);
	}
	else
	{
		printf("buf1 and buf2 are same %d \n", ret);
	}
	return 0;
}
