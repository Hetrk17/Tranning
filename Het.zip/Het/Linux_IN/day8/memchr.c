#include <stdio.h>
#include <string.h>

int main()
{
	const char str[] = "Linuxkernal.com";
	const char ch = '.';
	char *ret;
	printf("String before set/initializarion is %s \n", str);
	ret = memchr(str,ch,strlen(str));
	printf("String after **%c** is %s \n", ch,  ret-7);
	return 0;
}
