#include <stdio.h>
#include <string.h>

int main()
{
	const char str[] = "Linuxkernal.com";
	const char ch = '#';
	printf("String before set/initializarion is %s \n", str);
	memset(str,ch,strlen(str)-4);
	printf("String after set/initializarion is %s \n", str);
	return 0;
}
