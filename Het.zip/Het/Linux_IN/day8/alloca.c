#include <stdio.h>
#include <string.h>

int main()
{
	char *str1 = "Het ";
	const *str2 = "Kanzariya";
	
	char *name = (char *) alloca (strlen(str1) + strlen(str2)+1);
	
	stpcpy(stpcpy(name,str1),str2);
	
	printf("The copied string data is = %s \n", name);
	return 0;
}
