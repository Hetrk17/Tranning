#include <stdio.h>
#include <string.h>

int main()
{
	char dest[] = "Oldstring";
	const char src[] = "newstring";
	int ret;
	
	printf("Before memmove dest = %s, src = %s \n", dest,src);
	memmove(dest,src,1);
	printf("After memmove dest = %s, src = %s \n", dest,src);
}
