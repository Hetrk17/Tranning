#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void sig_handler(int signum)
{
	printf("Inside handler function\n");
	exit(0);
}

void main()
{
	pid_t pid;
	signal(SIGUSR1, sig_handler);
	printf("Inside main function\n");
	pid = getpid();
	kill(pid,SIGUSR1);
	printf("Inside main function\n");
	while(1);
}
