#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void check_blocked_sigs()
{
	int i,res;
	sigset_t s;
	sigprocmask(SIG_BLOCK,NULL,&s);
	for(i=1;i<5;i++)
	{
		res = sigismember(&s,i);
		if(res)
		{
			printf("Signal %d is blocked \n",i);
		}
		else
		{
			printf("Signal %d is not blocked \n",i);
		}
	}
}

void main()
{
	sigset_t s_set;
	sigemptyset(&s_set);   
	sigaddset(&s_set,2);   
	perror("sig2");
	sigaddset(&s_set,4);   
	perror("sig4");
	sigprocmask(SIG_BLOCK|SIG_SETMASK, &s_set,NULL);
	perror("sigmask");
	check_blocked_sigs();
	sigprocmask(SIG_UNBLOCK, &s_set,NULL);
	printf("\nAfter unblocking\n");
	check_blocked_sigs();
}
