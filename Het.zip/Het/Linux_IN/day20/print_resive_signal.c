#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void sig_handler(int signum)
{
	
	if(signum == SIGINT)
	{
		printf("\nI am  in  sighhandler of %d \n", signum);
		printf("\nI am  in  sighhandler of Ctrl+C \n");
	}
	else
	{
		printf("\nI am  in  sighhandler of %d \n", signum);
	}
	exit(0);
}

void main()
{
	signal(2,sig_handler);
	printf("In main function \n");
	while(1);
}
