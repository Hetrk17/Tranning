#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void check_blocked_sigs(sigset_t s)
{
	int i,res;
	for(i=1;i<5;i++)
	{
		res = sigismember(&s,i);
		if(res)
		{
			printf("Signal %d is pending \n",i);
		}
		else
		{
			printf("Signal %d is not pending \n",i);
		}
	}
}

void main()
{
	sigset_t s_set,s;
	sigemptyset(&s_set);   
	sigaddset(&s_set,2);   
	perror("sig2");
	sigaddset(&s_set,4);   
	perror("sig4");
	sigprocmask(SIG_BLOCK|SIG_SETMASK, &s_set,NULL);
	perror("sigmask");
	printf("Send me signal one and see the effect now \n");
	getchar();
	getchar();
	sigpending(&s);
	check_blocked_sigs(s);
	getchar();
	sigprocmask(SIG_UNBLOCK, &s_set,NULL);
	printf("\nAfter unblocking\n");
	check_blocked_sigs(s);
	while(1);
}
