#include<stdio.h>
#include<string.h>

int main()
{
	int x = 1234;
	int arr[5] = {10,11,12,13,14};
	char buff[] = "Kernal";
	
	printf("buff data:%s\n",buff);
	return 0;
}
