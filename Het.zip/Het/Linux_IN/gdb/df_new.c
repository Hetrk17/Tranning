#include<stdio.h>
#include<stdlib.h>
extern int EF_PROTECT_BELOW;


void buggy(int *p)
{
	*p = 10;
	printf("value at ptr intptr = %d\n", (*p));
	free(p);
	
}

int main()
{
	int *intptr;
	int i;
	intptr = (int *)malloc(sizeof(int));
	*intptr = 100;
	buggy(intptr);
	free(intptr);
	return 0;
}
