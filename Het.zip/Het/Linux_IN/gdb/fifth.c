#include<stdio.h>
#include<string.h>

struct student
{
	int roll;
	char name[40],gender __attribute__((aligned(0)));
	float height;
}__attribute__((packed));

int main()
{
	struct student first;
	printf("\n size of Struct A %3d\n",sizeof(first));
}
