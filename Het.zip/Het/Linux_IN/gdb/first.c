#include<stdio.h>
#include<string.h>

struct student
{
	int roll;
	char name[63],gender;
	float height;
}first;

int main()
{
	struct student second;
	struct student third = {103,"Hari Prasad. D",'M',5.11};
	
	printf("\n Roll\tname\t\t\t\t\t\tGender\tHeight\n");
	first.roll=101;
	strcpy(first.name,"Het Kanzariya");
	first.gender='M';
	first.height = 5.6;
	printf("\n %3d\t%-40s\t%c\t%1.2f",first.roll,first.name,first.gender,first.height);
	printf("\n %3d\t%-40s\t%c\t%1.2f\n",third.roll,third.name,third.gender,third.height);
	
	printf("\n size of Struct A %3d\n",sizeof(first));
}
