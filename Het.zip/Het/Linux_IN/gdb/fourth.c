#include<stdio.h>
#include<string.h>

struct student
{
	int roll;
	char name[40],genderA,genderB;
	float height;
}first;

int main()
{
	printf("\n size of Struct A %3d\n",sizeof(first));
}
