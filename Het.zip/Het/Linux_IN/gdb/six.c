#include<stdio.h>


void main()
{
	int *p1;
	
	//p1 = NULL;
	//printf("Null pointer %d\n", *p1);
	
	int *p2;
	printf("not inisalize pointer %d\n", *p2);
}
