#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<stdlib.h>

void sig_handler(int signum)
{
	printf("I am  in  sighhandler\n");
	exit(0);
}

int main()
{
	sigset_t s_set;
	signal(2,sig_handler);
	sigemptyset(&s_set);   //inicalise the empty set
	sigaddset(&s_set,2);    // add signal2 in signal set
	perror("sig2");
	sigprocmask(SIG_BLOCK|SIG_SETMASK, &s_set,NULL);
	perror("sigmask");
	printf("Send me signal one and see the effect now \n");
	printf("PID of process is ");
	getchar();
	getchar();
	sigprocmask(SIG_UNBLOCK, &s_set,NULL);
	printf("Now signals are unblocked \n");
	while(1);
	return 0;
}
