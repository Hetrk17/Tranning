#include<stdio.h>
#include<stdlib.h>
int j;
void buggy()
{
	int *intptr;
	int i;
	intptr = (int *)malloc(sizeof(int)*5);
	printf("Malloc checking : Addr = %08x and Size = %d\n",intptr,sizeof(int)*5);
	for(i=0;i<5;i++)
	{
		* intptr = 100;
		printf("value at ptr intptr = %d\n", (*intptr));
		intptr++;
	}
}

int main()
{
	int i;
	i=0;
	int k;
	k = 0;
	char str[50] = "Hello";
	buggy();
	return 0;
}
