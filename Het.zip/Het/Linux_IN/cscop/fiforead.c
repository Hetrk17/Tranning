#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
int j;

void buggy()
{
	int *intptr;
	int i;
	intptr = (int *)malloc(sizeof(int)*5);
	printf("Malloc checking : Addr = %08x and Size = %d\n",intptr,sizeof(int)*5);
	for(i=0;i<5;i++)
	{
		* intptr = 100;
		printf("value at ptr intptr = %d\n", (*intptr));
		intptr++;
	}
}

void main()
{
	int i;
	int k;
	char s[20];
	int fd;
	char str[50] = "Hello";
	mkfifo("newfifo1",644);
	
	perror("mkfifo");
	
	printf("Befour open() ....\n");
	fd = open("newfifo11", O_WRONLY);
	printf("After open()......");
	
	
	read(fd,s,sizeof(s));
	printf("Data: %s\n",s);
}
