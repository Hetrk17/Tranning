#include<stdio.h>

void main()
{
	printf("Hi\n");
}

