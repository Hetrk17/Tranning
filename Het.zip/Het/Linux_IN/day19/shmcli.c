#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/sem.h>
#include<sys/stat.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<string.h>

#define MY_KEY 199
#define SHM_SIZE 0x1000
#define MSG_LEN 256
#define RESP_MSG_START 256

int main()
{
	int semID,shmID;
	char *pShm;
	struct sembuf smop;
	semID = semget(MY_KEY,1,0660);
	if(semID < 0)
	{
		printf("Cloude not create semaphore\n");
		return (1);
	}
	else
	{
		printf("Opened a semaphore.ID is %d\n", semID);
	}
	shmID = shmget(MY_KEY,SHM_SIZE,0660);
	if(shmID < 0)
	{
		printf("Coude not create semaphore\n");
		return (2);
	}
	pShm = shmat(shmID, NULL, 0);
	if(!pShm)
	{
		printf("Coude not create semaphore\n");
		return (3);
	}
	while(1)
	{
		printf("Clinte: Enter some request message to send to serverr\n");
		fgets(pShm,MSG_LEN,stdin);
		smop.sem_num = 0;
		smop.sem_op = 1;
		smop.sem_flg = 0;
		
		semop(semID, &smop, 1);
		
		smop.sem_num = 1;
		smop.sem_op = -1;
		smop.sem_flg = 0;
		
		semop(semID, &smop, 1);
		puts(pShm+RESP_MSG_START);
	}
}
