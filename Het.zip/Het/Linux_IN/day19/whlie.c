#include<stdio.h>
#include<unistd.h>
void main()
{
	while(1)
	{
		printf("PID:- %d\n", getpid());
		for(int i=0; i<50000000; i++);
	}
}
