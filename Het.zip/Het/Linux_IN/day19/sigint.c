#include<stdio.h>
#include<signal.h>

void sighand(int signum)
{
	printf("Intrupt signal rec'd ... but no termiation on ctrl+c \n");
	signal(SIGINT,SIG_DFL);
}

void main()
{
	int i;
	signal(SIGINT,sighand);
	for(i=0;;i++)
	{
		printf("Inside main fun:- %d \n", i);
		sleep(1);
	}
}
