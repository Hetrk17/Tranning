#include<stdio.h>
#include<fcntl.h>

int main()
{
	printf("My process pid %d \n", getpid());
	printf("Perent process PID %d \n", getppid());
	while(1);
	return 0;
}
