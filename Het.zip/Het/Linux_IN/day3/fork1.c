#include<stdio.h>
void main()
{
	int pid_1,pid_2;
	printf("Current process pid = %d\n", getpid());
	pid_1 = fork();
	//pid_1 = vfork();
	if(pid_1 == 0)
	{
		sleep(5);	
		printf("new child process id = %d\n", getpid());
		printf("new child perent process id = %d\n", getppid());
		
	}
	else
	{
		//sleep(3);
		printf("new Perent process id = %d\n", getpid());
		printf("new Perent perent process id = %d\n", getppid());
		while(1);
	}

}
