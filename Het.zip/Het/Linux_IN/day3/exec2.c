#include<stdio.h>

void main()
{
	printf("Main\n");
	int rel;
	//execl("/bin/ls", "ls","-lh", 0);
	//execl("/home/het/Het/Linux_IN/day3/fork1.c","fork1.c" ,0);
	rel = execl("/usr/bin/vim","vim","info1.txt",0);
	printf("Never print\n");
}
