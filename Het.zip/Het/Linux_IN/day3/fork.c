#include<stdio.h>
void main()
{
	printf("St1 \n");
	fork();
	fork();
	printf("St2 \n");
	while(1);
}
