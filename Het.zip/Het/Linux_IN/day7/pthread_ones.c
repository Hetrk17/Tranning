#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>

pthread_once_t once = PTHREAD_ONCE_INIT;
void *myinit()
{
	printf("I am the init function\n");
}
void* theradfunc(void *arg)
{
	printf("I am in thread %d \n", (int *)arg);
	pthread_once(&once,(void *)myinit);	
	//sleep(1);
	printf("%d Thread Completed\n",(int *)arg);
}

int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2,tid3;
	pthread_create(&tid1, NULL, theradfunc, (void *)1);
	pthread_create(&tid2, NULL, theradfunc, (void *)2);
	pthread_create(&tid3, NULL, theradfunc, (void *)3);
	printf("Thread Call\n");
	sleep(3);
	printf("Main Completed\n");
	pthread_exit(NULL);
	exit(0);
}
