#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

void* Proc1(void* param)
{
	printf("\n I am in %d thread \n", (int *)param);
	//sleep(3);
	for(int i=0; i<4000000; i++)
	{
	}
	printf("\n %d thread Completed\n", (int *)param);
}


void* Proc2(void* param)
{
	printf("\n I am in %d thread \n", (int *)param);
	//sleep(3);
	
	printf("\n %d thread Completed\n", (int *)param);
}


int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	struct sched_param param;
	int priority,policy,ret;
	
	pthread_getschedparam(pthread_self(),&policy,&param);
	printf("\n-----------------Main Thread------------------------\n");
	printf("Policy:- %d, Priority:- %d\n",policy,param.sched_priority);
	//policy = SCHED_RR;
	//policy = SCHED_OTHER;
	policy = SCHED_FIFO;
	param.sched_priority = 30;
	pthread_setschedparam(tid1,policy,&param);
	param.sched_priority = 3;
	pthread_setschedparam(tid2,policy,&param);
	
	printf("Policy Updeted\n");
	pthread_getschedparam(tid1,&policy,&param);
	printf("\n-----------------Updated Thread------------------------\n");
	printf("Policy:- %d, Priority:- %d\n",policy,param.sched_priority);
	
	
	pthread_create(&tid1, NULL, Proc1, (void *) 1);
	//printf("Thread Call 1\n");
	
	
	pthread_create(&tid2, NULL, Proc2, (void *) 2);
	//printf("Thread Call 2\n");
	sleep(3);
	printf("Main Completed\n");
	pthread_exit(NULL);
	exit(0);
}
