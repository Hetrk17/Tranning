#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

void* Proc(void* param)
{
	sleep(3);
	return 0;
}


int main(int arg, char *ardv[])
{
	pthread_attr_t Attr;
	pthread_t tid1;
	int info;
	pthread_attr_init(&Attr);
	pthread_attr_getinheritsched(&Attr,&info);
	switch(info)
	{
		case PTHREAD_INHERIT_SCHED:
			printf("Child sched\n");
			break;
		case PTHREAD_EXPLICIT_SCHED:
			printf("Child explicit\n");
			break;
	}
	
	pthread_create(&tid1, NULL, Proc, NULL);
	printf("Thread Call\n");
	sleep(3);
	printf("Main Completed\n");
	pthread_exit(NULL);
	exit(0);
}
