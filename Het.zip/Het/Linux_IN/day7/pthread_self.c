#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
struct my_thread
{
	int thread_id;
	char msg[100];
};
void *PrintHello(void *threadobj)
{
	pthread_t thread_ID;
	struct my_thread *t1;
	t1 = (struct my_thread *) threadobj;
	thread_ID = pthread_self();
	printf("\nThread ID : %u\n", thread_ID);
	printf("\n%d Thread Message : %s\n", t1->thread_id, t1->msg);
}
int main()
{
	pthread_t thread1, thread2;
	int rc;
	struct my_thread t1, t2;
	t1.thread_id = 1;
	strcpy(t1.msg, "\nI am First Thread\n");
	t2.thread_id = 2;
	strcpy(t2.msg, "\nI am Second Thread\n");
	thread_ID = pthread_self();
	printf("\n Main Thread ID : %u",thread_ID);
	pthread_create(&t1,NULL,PrintHello, (void *)&t1);
	pthread_create(&t2,NULL,PrintHello, (void *)&t2);
	
	printf("\n Exit from main");
	pthread_exit(NULL);
	return;
}


