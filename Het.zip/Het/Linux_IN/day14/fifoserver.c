#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>

int main(void)
{
	printf("Server - listening");
	
	int code = mkfifo("cli_ser_fifo",0764);
	
	if(code == -1)
	{
		perror("mkfifo returned an error - file may already exit\n");
	}
	
	int fd = open("cli_ser_fifo",O_RDONLY);
	if(fd == -1)
	{
		perror("Cannot open FIFO for read\n");
		return 0;
	}
	printf("FIFO OPEN\n");
	
	char serverrcv[100];
	memset(serverrcv,0,100);
	
	int res;
	char Len;
	while(1)
	{
		res = read(fd, &Len, 1);
		if(res==0)
		{
			break;
		}
		read(fd, serverrcv, Len);
		printf("Server received: %s \n", serverrcv);
	}
	printf("EOF Reached\n");
	close(fd);
	printf("FIFO Closed\n");
	return 0;
}
