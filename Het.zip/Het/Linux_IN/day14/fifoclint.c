#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<string.h>

int main(void)
{
	printf("Client process writing\n");
	char clintmsg[] = "LLinux System Kernal Programming";
	int fd = open("cli_ser_fifo",O_WRONLY);
	if(fd == -1)
	{
		perror("Cannot open FIFO for read\n");
		return EXIT_FAILURE;
	}
	
	write(fd, clintmsg, strlen(clintmsg));
	close(fd);
	return 0;
}
