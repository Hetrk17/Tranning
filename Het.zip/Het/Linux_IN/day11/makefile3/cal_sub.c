#include<stdio.h>
double sub(double a, double b)
{
	printf("Sub\n");
	return a-b;
}
