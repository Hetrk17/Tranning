double add(double a, double b)
{
	return (a+b);
}
