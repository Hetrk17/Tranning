double sub(double a, double b);
double mean(double a, double b);
double add(double a, double b);
