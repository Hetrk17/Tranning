#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	char buff_comm[5];
	strcpy(buff_comm,"ls -l");
	printf("system() library function uses forck() to create a child process\n ");
	printf("Child process executes execl() which loads and run new program provided by atatem() argument\n");
	//int i = system(NULL);
	printf("i:- %d\n", i);
}
