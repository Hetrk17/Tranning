#include<stdio.h>
#include<fcntl.h>

void main()
{
	int id1 = creat("linux001.txt",777);
	printf("File discripter is %d", id1);
}

