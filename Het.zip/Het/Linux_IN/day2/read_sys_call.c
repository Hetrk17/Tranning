#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
	int fd, len;
 	int x;
	char read_buf[70];	
	fd = open("linux003.txt",O_CREAT |O_RDWR, 0777);
	if(fd<0)
	{
		printf("File is not opend or created\n");
	}
	read(fd,read_buf,70);
	printf("Data of file is = %s", read_buf);
	close(fd);
}

