#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
	int fd, len;
 	int x;
	char write_buf[60] = "Write system call check\n";	
	fd = open("linux003.txt",O_CREAT |O_RDWR, 0777);
	write(fd,write_buf,60);
	close(fd);
}
