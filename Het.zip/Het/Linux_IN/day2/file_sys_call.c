#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
void main()
{
	int fd, len;
 	int x;
	char read_buf[70];
	char write_buf[60] = "Creat_Write_Read system call check\n";		
	fd = open("linux004.txt",O_CREAT |O_RDWR, 0777);
	if(fd<0)
	{
		printf("File is not opend or created\n");
	}
	printf("Open done\n");
	x = write(fd,write_buf,60);
	printf("Write done\n");
	printf("\n\n start form begning");
	lseek(fd,0,SEEK_SET);	
	read(fd,read_buf,70);
	printf("Read done\n");	
	printf("Data of file is = %s", read_buf);
	
	lseek(fd,0,SEEK_SET);	
	read(fd,read_buf,70);
	printf("Read done\n");	
	printf("Data of file is = %s", read_buf);
	lseek(fd,0,SEEK_SET);	
	read(fd,read_buf,70);
	printf("Read done\n");	
	printf("Data of file is = %s", read_buf);
	close(fd);
}

