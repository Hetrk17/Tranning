#include<stdio.h>
#include<fcntl.h>

void main()
{
	int id1 = open("linux001.txt",O_WRONLY,777);
	printf("File discripter is %d", id1);
}
