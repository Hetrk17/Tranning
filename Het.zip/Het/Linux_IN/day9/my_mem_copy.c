#include <stdio.h>
#include <string.h>

void my_mem_copy(void *src,  void *dest, size_t nbyte)
{
	int i; 
	char *dest1 = (char *)dest;
	char *src1 = (char *)src;
	for(i=0;i<nbyte;i++)
	{
		*dest1 = *src1;
		dest1++;
		src1++;
		
	}
}


int main()
{
	char dest[] = "Oldstring";
	char src[] = "newstring";
	int ret;
	
	printf("Before memmove dest = %s, src = %s \n", dest,src);
	my_mem_copy(src,dest,9);
	printf("After memmove dest = %s, src = %s \n", dest,src);
}
