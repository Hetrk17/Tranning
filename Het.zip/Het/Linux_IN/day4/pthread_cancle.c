#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<fcntl.h>

void *printHello(void *threadid)
{
	printf("Hello Word\n");
	while(1);
}

int main()
{
	pthread_t thread;
	int rc,t=0;
	printf("Creating thred \n");
	rc = pthread_create(&thread, NULL,printHello,NULL);
	printf("\n Thread ID : %u", thread);
	sleep(6);
	t=pthread_cancel(thread);
	if(t==0)
		printf("\n Thread Canceld\n");
	//printf("\n thread ID : %u \n",thread);
}
