#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>



struct char_print_params
{
	int count;
	char character;
};



void *char_print(void *parameters)
{
	struct char_print_params *p = (struct char_print_params) parameters;
	int i;
	printf("Structure char data: %c and %d", character, count);
}



void* threadFunc(void *arg)
{
	char *s = (char *) arg;
	printf("%s\n",s);
	return 0;
}



int main(int argc, char *argv[])
{
	pthread_t thread1_id;
	pthread_t thread2_id;
	struct char_print_params
	int s;
	s = pthread_create(&t1, NULL, threadFunc, "Hello World!");
	/*
	//checking in real time - as such not required
	if(s != 0)
	{
	printf("pthread_create error %d\n",s);
	return;
	}
	*/
	printf("Messages from main()\n");
	sleep(3);
	//pthread_join(tid, NULL);



return 0;
}
