#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

void* theradfunc(void *arg)
{
	
	
	pid_t pid;
	pthread_t tid;
	pid = getpid();
	tid = pthread_self();
	printf("PID %u tid %u \n", (unsigned int)pid, (unsigned int)tid);
	return 0;
}

int main(int arg, char *ardv[])
{
	pthread_t tid;
	int err;
	err = pthread_create(&tid, NULL, theradfunc, NULL);
	
	while(1);
	exit(0);
}
