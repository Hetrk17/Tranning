#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<fcntl.h>
int fd;
void* theradfunc(void *arg)
{

	char *str, buff[100];
	int n, pid;
	str = (char *)arg;
	pid = getpid();	
	printf("%s: \t Start Now: \t For Process %d \n\n",str,pid);
	do
	{
		n = read(fd,buff,100);
		printf("%s \t Read: \t %d \n\n", str,pid);
		printf("\n --------------------- \n");
		write(1,buff,n);
		printf("\n --------------------- \n");
		sleep(3);
	}while(n);
	printf("%s: \t Finished Now: \t For Process %d \n\n",str,pid);

}

int main(int arg, char *ardv[])
{
	pthread_t tid1, tid2;

	
	fd = open("etc/passwd",O_RDONLY);
	printf("File is opened with fd = %d \n",fd);

	int err;
	pthread_create(&tid1, NULL, theradfunc, NULL);
	pthread_create(&tid2, NULL, theradfunc, NULL);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	exit(0);
}
