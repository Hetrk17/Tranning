#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
static void* threadFunc(void *arg)
{
	char *s = (char *) arg;
	printf("%s\n",s);
	return (void*) strlen(s);
	//return 0;
}

int main(int arg, char *ardv[])
{
	pthread_t t1;
	void *res;
	int s;
	
	pthread_create(&t1 , NULL , threadFunc , "Hello world");
	printf("Massage from main()\n");
	//sleep(3);
	pthread_join(t1,&res);
	printf("Thread returned %ld\n", (long)res);
	exit(0);
}
