#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>
void* theradfunc(void *arg)
{
	pthread_detach(pthread_self());
	printf("Entered thread , sleep 2 \n");	
	sleep(1);
	printf("Thread Completed\n");
}

int main(int arg, char *ardv[])
{
	pthread_t tid1;
	pthread_create(&tid1, NULL, theradfunc, NULL);
	printf("Thread Call\n");
	sleep(3);
	printf("Main Completed\n");
	exit(0);
}
