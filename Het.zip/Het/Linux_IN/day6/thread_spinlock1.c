#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>
int sharedVar = 5;
static pthread_spinlock_t spinlock;
volatile int slock;
int rc = 0;
void* theradfunc_spinlock(void *arg)
{
	rc = pthread_spin_lock(&slock);
	int count=0;
	sleep(1);
	printf("Entered thread , getting Spin lock \n");
	rc = pthread_spin_unlock(&slock);
	
	printf("Thread Completed\n");
}

int main(int arg, char *ardv[])
{
	pthread_t tid1;
	if(pthread_spin_init(&slock,PTHREAD_PROCESS_PRIVATE)!=0)
		perror("init");
	printf("Main, get spin lock\n");
	rc = pthread_spin_lock(&slock);
	printf("Main, create the spin lock thread\n ");
	pthread_create(&tid1, NULL, theradfunc_spinlock, NULL);
		sleep(3);
	printf("Main, Now unlock the spin lock\n");
	rc = pthread_spin_unlock(&slock);

	if(rc==0)
	{
		printf("Main, sucessfully unlock the spin lock\n");
	}
	else
	{
		printf("Main, Not unlock the spin lock\n");
	}
	//sleep(5);
	printf("Main wait to exicute the thread\n");
	
	//pthread_join(tid1,NULL);
	pthread_exit(NULL);
	
	printf("Main Completed\n");
	exit(0);
}
