#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>
int sharedVar = 5;
sem_t mysem;

void* theradfunc_inc(void *arg)
{
	sem_wait(&mysem);
	//sleep(3);
	sharedVar++;
	printf("After incr = %d\n", sharedVar);
	sem_post(&mysem);
}

void* theradfunc_decr(void *arg)
{
	sem_wait(&mysem);
	sharedVar--;
	printf("After decr = %d\n", sharedVar);
	return 0;
	sem_post(&mysem);
}
int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	int err;
	sem_init(&mysem,0,1);
	pthread_create(&tid1, NULL, theradfunc_inc, NULL);
	pthread_create(&tid2, NULL, theradfunc_decr, NULL);
	
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	printf("sharedVar = %d \n ", sharedVar);
	exit(0);
}
