#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>
#define NUM_thread 3
int i=0;
void* theradfunc(void *arg)
{
	//printf("Thread %d Start\n",i);
	i++;
	int result = 0;
	result = result + i*(1000);
	printf("Result = %d \n", result);	
	printf("Thread %d Completed\n",i);
	pthread_exit(NULL);
}

int main(int arg, char *ardv[])
{
	pthread_t tid[NUM_thread];
	pthread_attr_t attr;

	int detach_state,rs,t,status;

	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	
	for(t=0; t<NUM_thread; t++)
	{
		pthread_create(&tid[t], &attr, theradfunc, NULL);	
	}	
	pthread_attr_getdetachstate(&attr, &detach_state);
	printf("Detach State: %d\n", (int *)detach_state);
	printf("Main Completed\n");
	pthread_exit(NULL);
	exit(0);
}
