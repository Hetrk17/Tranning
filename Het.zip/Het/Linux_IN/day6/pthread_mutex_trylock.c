#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>
int sharedVar = 5;
pthread_mutex_t my_mutex;

void* theradfunc_inc(void *arg)
{
	pthread_mutex_trylock(&my_mutex);
	sleep(3);
	sharedVar++;
	printf("After incr = %d\n", sharedVar);
	pthread_mutex_unlock(&my_mutex);
}

void* theradfunc_decr(void *arg)
{
	pthread_mutex_trylock(&my_mutex);
	//sleep(3);
	sharedVar--;
	printf("After decr = %d\n", sharedVar);
	pthread_mutex_unlock(&my_mutex);
}

int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	int err;

	pthread_mutex_init(&my_mutex,NULL);
	pthread_create(&tid1, NULL, theradfunc_inc, NULL);
		sleep(3);
	pthread_create(&tid2, NULL, theradfunc_decr, NULL);
	
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	printf("sharedVar = %d \n ", sharedVar);
	exit(0);
}
