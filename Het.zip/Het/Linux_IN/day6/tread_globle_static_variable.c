#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

int sharedVar = 5;


void* theradfunc_inc(void *arg)
{
	sleep(3);
	sharedVar++;
	printf("After incr = %d\n", sharedVar);
	return 0;
}

void* theradfunc_decr(void *arg)
{
	sharedVar--;
	printf("After decr = %d\n", sharedVar);
	return 0;
}
int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	int err;
	pthread_create(&tid1, NULL, theradfunc_inc, NULL);
	pthread_create(&tid2, NULL, theradfunc_decr, NULL);
	
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	printf("sharedVar = %d \n ", sharedVar);
	exit(0);
}
