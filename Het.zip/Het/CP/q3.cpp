#include<fstream>
#include<iostream>
#include<string>
using namespace std;

template <class T>
class A
{
	T j;
	public:
	void fun(const T &x)
	{
		static int i=10;
		cout << "size of variable in class" << sizeof(j) << endl;
		cout<< ++i << endl;
		return;
	}
};

int main()
{
	
	int in=0;
	int c;
	double fl=8.2;
	
	A<int> ob1;
	A<double> ob2;
	cout<<"\nOb1\n";
	ob1.fun(in);
	ob1.fun(in);
	ob1.fun(fl);
	ob1.fun(fl);
	
	
	cout<<"\nOb2\n";
	ob2.fun(in);
	ob2.fun(in);
	ob2.fun(fl);
	ob2.fun(fl);
	/*c = ob1.fun(in);
	c = ob1.fun(fl);
	A<float> ob2;
	c = ob2.fun(in);
	c = ob2.fun(fl);*/
	return 0;
}
