#include<iostream>
using namespace std;



class Complex
{
    int real, img;
    public:
	Complex()
	{
		real = 0;
		img = 0;
	}
	Complex(int x, int y)
	{
		real = x;
		img = y;
	}
	void display()
	{
		cout << "\nComplex Number:- "<< real << " + " << img << "i \n";
	}
	friend Complex operator + (Complex ob1, Complex b2);
	friend Complex operator ++ (Complex ob1);
	
};
Complex operator + (Complex ob1, Complex ob2)
	{
		Complex temp;
		//cout << "\nIn + function \n";
		//cout << "first Complex Number:- "<< real << " + " << img << "i \n";
		//cout << "second Complex Number:- "<< ob.real << " + " << ob.img << "i \n";
		temp.real = ob1.real + ob2.real;
		temp.img = ob1.img + ob2.img;
		return temp;
	}
	
Complex operator ++ (Complex ob1)
	{
		Complex temp;
		cout << "\nIn ++ function \n";
		cout << "first Complex Number:- "<< ob1.real << " + " << ob1.img << "i \n";
		temp.real = ++ob1.real;
		temp.img = ++ob1.img;
		return temp;
	}


int main()
{
	Complex c1(15,20), c2(5,10);
	Complex c3(1,1),c4;
	cout << "Object1";
	c1.display();
	cout << "Object2";
	c2.display();
	//cout << "Object3";
	//c3.display();
	c4 = c1 + c2;
	cout << "\nob1 + ob2";
	c4.display();
	c4 = ++c1;
	cout << "\n++ob1";
	c4.display();
}
