//Het Kanzariya
#include <deque>
#include <iostream>

using namespace std;

int main()
{
	deque<int> Qmin,Qmax;
	int N, k,num,i;
	int arr[N];
	cout << "Enter value Of N";
	cin >> N;
	cout << "Enter value Of S";
	cin >> k;
	
	for(i=0;i<N;i++)
	{
		cin >> arr[i];
	}

    	for (i = 0; i < k; ++i)
    	{
        	while ((!Qmax.empty()) && arr[i] >=arr[Qmax.back()])
           		Qmax.pop_back();
        	Qmax.push_back(i);
    	}
    	for (; i < N; ++i)
    	{
     
        	cout << arr[Qmax.front()] << " ";
 
    
	        while ((!Qmax.empty()) && Qmax.front() <= i - k)
          		Qmax.pop_front();

        	while ((!Qmax.empty()) && arr[i] >= arr[Qmax.back()])
            		Qmax.pop_back();
 
        	Qmax.push_back(i);
    	}
    cout << arr[Qmax.front()];
}

	  


