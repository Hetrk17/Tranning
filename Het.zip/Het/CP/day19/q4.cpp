#include<iostream>
#include<vector>
using namespace std;

int main()
{
	vector<char> v(10);
	vector<char>::iterator p;
	vector<char>::iterator p2;
	int i;
	p = v.begin();
	i=0;
	while(p != v.end())
	{
		*p = i + 'a';
		p++;
		i++;
	}
	cout<< "Orignal contants:\n";
	p=v.begin();
	while(p != v.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	p=v.begin();
	while(p != v.end())
	{
		*p = toupper(*p);
		p++;
	}
	cout<< "Modify contants:\n";
	p=v.begin();
	while(p != v.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	//////////////////////////Insert///////////////////////////
	p=v.begin();
	char ch = 'C';
	while(*p != ch) //itreter is pointing to C
	{
		p++;
		if(p == v.end())
		{
			cout<<"Not found"<<endl;
			break;
		}
	}
	v.insert(p,2,'Y');  //two Y are added at P itreter. 
	cout<< "Two 'Y' are added before 'C':\n";
	p=v.begin();
	while(p != v.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	//////////////////////////Remove/////////////////////////////
	ch = 'F';
	p=v.begin();
	while(*p != ch) //itreter is pointing to F
	{
		p++;
		if(p == v.end())
		{
			cout<<"Not found"<<endl;
			break;
		}
	}
	v.erase(p); //remove elemnt at itreter P point
	cout<< "'F'  removed:\n";
	p=v.begin();
	while(p != v.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	//////////////////////////Remove Between//////////////////////
	
	ch = 'D';
	char ch2 = 'I';
	p=v.begin();
	while(*p != ch) //itreter is pointing to F
	{
		p++;
		if(p == v.end())
		{
			cout<<"Not found"<<endl;
			break;
		}
	}
	p2 = p;
	while(*p2 != ch2) //itreter is pointing to F
	{
		p2++;
		if(p2 == v.end())
		{
			cout<<"Not found"<<endl;
			break;
		}
	}
	v.erase(p,p2); //remove elemnt at itreter P point
	cout<< "'D' to 'I'  removed:\n";
	p=v.begin();
	while(p != v.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	
	return 0;
}
