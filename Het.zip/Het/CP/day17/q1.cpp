#include<fstream>
#include<iostream>
using namespace std;

template <class T, typename Y>
T sum(T n1, Y n2)
{
	//T rs;
	//rs = n1+n2;
	//return rs;
	return n1+n2;
}
int main()
{
	int A = 10, B = 20, C;
	float a = 11.5, b =22.3, c;
	
	cout<< "Addtion of integer is " << sum(A,B) << endl;
	cout<< "Addtion of long is " << sum(a,b) << endl;
	cout<< "Addtion of long and integer is " << sum(A,b) << endl;
	cout<< "Addtion of intger and long is " << sum(a,B) << endl;
	cout<< "Addtion of intger and long is " << sum(10.6,20) << endl;
	return 0;
}
