#include<fstream>
#include<iostream>
#include<string>
using namespace std;

template <class T, class U>
class Addition
{
	public:
		U add(T n1, U n2)
		{
			return n1 + n2;
		}
};

int main()
{
	Addition<int,float> ob1;
	Addition<float,float> ob2;
	cout << "Sum of int: " << ob1.add(10.8,20.7) << endl;
	cout << "Sum of float: " << ob2.add(10.5,20.7) << endl;
	return 0;
}
