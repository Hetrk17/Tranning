#include<fstream>
#include<iostream>
#include<string>
using namespace std;

template <class T>

void swap(T *n1, T *n2)
{
	T temp;
	temp = *n1;
	*n1 = *n2;
	*n2 = temp;
}
int main()
{
	int A = 10, B =11;
	float a = 10.5, b =  11.3;
	
	string e = "Het", f = "Kanzariya";
	cout << "Integer\n";
	cout << "Before Swap"<<" "<<A<<" "<< B <<"\n";
	swap(&A,&B);
	cout << "After Swap"<<" "<<A<<" "<< B <<"\n";
	
	cout << "\nFloat\n";
	cout << "Before Swap"<<" "<<a<<" "<< b <<"\n";
	swap(&a,&b);
	cout << "After Swap"<<" "<<a<<" "<< b <<"\n";
	
	cout << "\nString\n";
	cout << "Before Swap"<<" "<<e<<" "<< f <<"\n";
	swap(e,f);
	cout << "After Swap"<<" "<<e<<" "<< f <<"\n";
	return 0;
}
