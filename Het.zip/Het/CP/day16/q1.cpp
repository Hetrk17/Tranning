#include<fstream>
#include<iostream>
using namespace std;
int main()
{
	ofstream oflie;
	ofile.open("file.txt");
	ofile<<"Line one in the document"<endl;
	oflie<<"Another line"<<endl
}
