#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream f;
	int pos;
	char buf[100];
	f.open("data1.txt");
	f << "hello world";
	pos = f.tellg();
	cout <<"pos pointer is at: " << pos << endl;
	f.close();
	cout<<"Done!!"<<endl;
	f.open("data1.txt");
	cout<<"Reading the file"<<endl;
	f.seekg(0);
	while(f.getline(buf,100))
	{
		cout<<buf<<endl;
	}
	pos = f.seekg(0,ios::end);
	pos = f.tellg();
	cout <<"pos pointer is at: " << pos << endl;
	return 0;
}
