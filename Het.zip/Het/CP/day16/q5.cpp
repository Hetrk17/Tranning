#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	ofstream f;
	f.open("data.txt");
	f << "1234567890";
	long pos = f.tellp();
	f.seekp(pos+6);
	f << "my file";
	pos = f.tellp();
	f.seekp(pos-3);
	f << "Again again my file";
	f.seekp(7,ios::beg);
	f << "Append at seven";
	f.seekp(7,ios::cur);
	f << "Random data";
	f.seekp(-4,ios::end);
	f << "Random data1";
	f.close();
	cout<<"Done!!";
	return 0;
}
