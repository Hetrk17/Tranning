#include<iostream>
#include<map>
#include<cstring>
using namespace std;

class name
{
	char str[40];
	public:
		name()
		{
			strcpy(str,"");
		}
		
		name(char *s)
		{
			strcpy(str,s);
		}
		
		char *get()
		{
			return str;
		}
};
bool operator<(name a,name b)
{
	return strcpy(a.get(),b.get())<0; 
}


class phoneNum
{
	char str[80];
	public:
		phoneNum()
		{
			strcpy(str,"");
		}
		
		phoneNum(char *s)
		{
			strcpy(str,s);
		}
		
		char *get()
		{
			return str;
		}
};


int main()
{
	map<name, phoneNum> dir1;
	dir1.insert(pair<name,phoneNum>(name("Emp1"),phoneNum("555-1111")));
	dir1.insert(pair<name,phoneNum>(name("Emp2"),phoneNum("555-2222")));
	dir1.insert(pair<name,phoneNum>(name("Emp3"),phoneNum("555-3333")));
	dir1.insert(pair<name,phoneNum>(name("Emp4"),phoneNum("555-4444")));
	
	char str[80];
	cout << "Enter Name: ";
	cin >> str;
	
	map<name,phoneNum>::iterator p;
	
	cout << "Size = " << dir1.size() << endl;
	
	p = dir1.find(name(str));
	if(p!=dir1.end())
		cout<<"Phone Number:- " << p->second.get() << endl;
	else
		cout << "Not in directrory.\n";
	return 0;
}
