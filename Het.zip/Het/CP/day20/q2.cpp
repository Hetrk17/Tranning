#include<iostream>
#include<list>
using namespace std;

int main()
{
	list<int> lst;
	list<int> lst1;
	int i;
	for(i=0;i<10;i++)
	{
		lst.push_back(rand()%20);
	}
	for(i=0;i<10;i++)
	{
		lst1.push_back(rand()%20);
	}
	cout << "Size = " <<lst.size() << endl;
	cout << "Contents: ";
	list<int>::iterator p;
	list<int>::iterator p1;
	p = lst.begin();
	p1 = lst1.begin();
	cout<< "Orignal contants P:\n";
	while(p!=lst.end())
	{
		cout << *p << " ";
		p++;
	}
	cout << "\n\n";
	
	/////////////////////////////////
	lst.sort();
	cout<< "short contants:\n";
	p=lst.begin();
	while(p != lst.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	////////////////////////////////
	cout<< "Orignal contants P1:\n";
	while(p1!=lst1.end())
	{
		cout << *p1 << " ";
		p1++;
	}
	cout << "\n\n";
	lst1.sort();
	lst.merge(lst1);
	cout<< "Merge contants P1:\n";
	p = lst.begin();
	while(p != lst.end())
	{
		cout << *p << " ";
		p++;
	}
	cout<< "\n\n";
	
	return 0;
}
