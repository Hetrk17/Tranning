#include<iostream>
using namespace std;

int main()
{
	int num,den;
	float ans;
	den = 0;
	num =3;
	try
	{
		if(den==num)
		{
			throw den;
		}
		else
		{
			if(den==0)
			{
				throw ans;
			}
			ans = (float)num/den;
			if(ans<0)
				throw 'e';
			cout<<"Result:"<< ans << "\n";

		}
	}
	catch(char ch)
	{
		cout <<"One Number is negative\n";		
	}
	catch(int x)
	{
		cout <<"Number is same\n";
	}
	catch(...)
	{
		cout <<"Exeption unknow\n";
	}
	cout << "End of the program"<<"\n";
	return 0;
}
