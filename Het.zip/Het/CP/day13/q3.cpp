#include<iostream>
using namespace std;

int main()
{
	int num,ans,zero;
	zero = 0;
	num =10;
	try
	{
		if(zero==0)
		{
			throw zero;
		}
		else
		{
			ans = num/zero;
			cout<<"Result:"<< ans;

		}
	}
	catch(int x)
	{
		cout <<"\n Can't devide by " <<x<<"\n";
	}
	cout << "End of the program"<<"\n";
	return 0;
}
