#include<iostream>
using namespace std;

int main()
{
	int a;
	cout << "Enter a Number\n";
	cin >> a;
	try
	{
		try
		{
			throw a;
			
		}
		//catch(int x)
		//{
		//	cout << "Ecepetion Inner try block.\n";
		//	throw x;
		//}
		
	}
	catch(int y)
	{
		cout << "Ecepetion outer try block.\n";	
	}
	return 0;
}
