#include<iostream>
using namespace std;
class A
{
	private:
	int a=10;
	protected:
   	int c = 50; 
   	public:
   	int b=20;
   	
   	class B 
   	{
      		private:
      		  int a1=30;
      		protected:
   		  int c1 = 60; 
      		public:
      		  int b1=40;     		
      		  void Bputdata(A *e) 
      		  {
        	 	cout<<"\n\nIn Inner Class"<<endl;
        	 	cout<<"Private Varible of outer class "<< e->a << endl;
        	 	cout<<"Public Varible of outer class "<< e->b << endl;
        	 	cout<<"Protected Varible of outer class "<< e->c << endl;
        	 	cout<<"Private Varible of inner class "<< a1 << endl;
        	 	cout<<"Public Varible of inner class "<< b1 << endl;
        	 	cout<<"Protected Varible of inner class "<< c1 << endl;
      		  }
   	};
   	
   	void Aputdata(A :: B *e) 
      	{
       		cout<<"\n\nIn Outer Class"<<endl;
       	 	cout<<"Private Varible of outer class "<< a << endl;
        	cout<<"Public Varible of outer class "<< b << endl;
        	cout<<"Protected Varible of outer class "<< c << endl;
        	//cout<<"Private Varible of inner class "<< e->a1 << endl;
        	//cout<<"Public Varible of inner class "<< e->b1 << endl;
        	//cout<<"Protected Varible of inner class "<< e->c1 << endl;
        }
   	
};
int main() 
{
	
	A obj1;
	A :: B obj;
	obj1.Aputdata(&obj);
	
	obj.Bputdata(&obj1);
	return 0;
}
