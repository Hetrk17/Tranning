#include<iostream>
using namespace std;
class A 
{
	public:	
	void displayA()
	{
		printf("Class A\n");
	}
};

class B : public A  
{
	public:
	void displayB()
	{
		printf("Class B\n");
	}
};


class C : public B
{
	public:
	void displayC()
	{
		printf("Class C\n");
	}
};


class D : public B, public C
{
	public:
	void displayD()
	{
		printf("Class D\n");
	}
};

int main()
{
	A a;
	B b;
	C c;
	D d;
	

	c.displayA();
	//b.displayA();
	b.displayC();
	b.displayD():
	c.displayB();
	d.displayB();
	d.displayC();
}
