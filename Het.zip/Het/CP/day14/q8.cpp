#include<iostream>
#include<exception>
using namespace std;

class Divide
{
	int *x;
	int *y;
	
	public:
	     Divide()
	     {
	     	x = new int();
	     	y = new int();
	     	cout << "Enter two numbers";
	     	cin>>*x>>*y;
	     	try
	     	{
	     		if(*y==0)
	     		{
	     			throw *x;
	     		}
	     	}
	     	catch(int m)
	     	{
	     		delete x; 
	     		delete y;
	     		cout <<"Second Number cannot be zero!\n";
	     		throw;
	     		//exit (0);
	     	}
	     }
	     ~Divide()
	     {
	     	try
	     	{
	    		delete x; delete y;
	    	}
	    	catch(...)
	    	{
	    		cout << "Error while deallocation memory\n";
	    		exit (0);
	    	}
	     }
	     float division()
	     {
	    		return (float)*x/ *y;
	     }
	     
};


int main()
{
	Divide ob1;
	float ans = ob1.division();
	cout << "Ans:- " << ans << "\n";
	return 0;
}
