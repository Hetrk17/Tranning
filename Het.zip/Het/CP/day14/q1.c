#include<iostream>
using namespace std;

void demo() throw(int,double)
{
	int a;
	cout << "Enter a Number\n";
	cin >> a;
		if(a==1)
		{
			throw a;
		}
		else if(a==2)
		{
			throw 'A';
		}
		else if(a==3)
		{
			throw 4.5;
		}
		else
		{
			throw true;
			cout << "Test\n";
		}
	
}

void main()
{
	try
	{
		demo();
	}
	catch(char ch)
	{
		cout <<"Number is \n";		
	}
	catch(int x)
	{
		cout <<"Number is 1\n";
	}
	
	catch(double y)
	{
		cout <<"Number is 3\n";
	}
	catch(...)
	{
		cout <<"Number is grater than 3\n";
	}
	cout << "End of the program"<<"\n";
}


