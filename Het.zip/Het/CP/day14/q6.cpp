#include<iostream>
#include<exception>
using namespace std;

class Base {}; 
class Derived : public Base {}; 
int main() 
{ 
	try 
	{
		throw Derived();
	}
	catch(Base b) 
	{
		cout<<"Base object caught\n";
	}
	catch(Derived d) 
	{
		cout<<"Derived object caught\n";
	}
	return 0;
}
