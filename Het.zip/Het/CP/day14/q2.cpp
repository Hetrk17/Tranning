#include<iostream>
using namespace std;



class Test{
	int x;
	public:
	void read()
	{
		cout << "Enter a number : ";
		cin >> x;
	}

	class EVEN{ }; //abstract class for exception
	class ODD{ };
	void check()
	{
		if(x%2 == 0)
		throw EVEN(); // here the object of Even is throw. You can throw class
		else
		throw ODD(); // ODD() is cunstruction of odd class object and throw odd object
	}
};

class EVEN{};


int main()
{
	Test t;
	t.read();
	try
	{
		t.check();
	}
	catch(Test::EVEN)  // scoup resolvution
	{
		cout << "Number is Even" << "\n";
	}
	catch(Test::ODD)
	{
		cout << "Number is Odd" << "\n";
	}
	return 0;


}
