#include<iostream>
#include<exception>
using namespace std;

int main()
{
	int a[5]= {1,2,3,4,5};
	int zero = 0;
	try 
	{
		//int* myarray = new int[100000000000000]; 
		int ans = 4/zero;
		//int ans = a[-10];
		//cout << ans << "\n";
	}
	catch(exception &e)
	{
		cout << "Std exeption" << e.what() << endl;
	}
	return 0;
}
