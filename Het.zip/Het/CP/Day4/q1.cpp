#include <iostream>  
using namespace std;



int& max(int &x, int &y)
{
	
	if (x>y)
		return ++x;
	else
		return ++y;
}

int main()
{
	int a,b;
	a = 10;
	b = 20;
	int ans = max(a,b);
	cout << "Max:- " << ans << "\n";
	
}
