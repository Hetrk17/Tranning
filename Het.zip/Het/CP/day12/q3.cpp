#include<iostream>
using namespace std;
class base 
{
	float y;
	public:
	base(float x)
	{
		y=x;
	}
	int getdata()
	{
		return y;
	}
};
int main()
{
	//base b;
	//derive d1;
	base d[3] = {10, 20 ,30};
	base *ptr = d;
	for(int i=0; i<3;i++)
	{
		cout<< ptr->getdata() << endl;
		cout << "Object " << i << " is " << ptr << "\n";
		ptr++;
	}
}
