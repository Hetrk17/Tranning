#include<iostream>
using namespace std;
class base 
{
		public:
	int a,b;

	void input (int a, int b)
	{
		this->a = a+b;
		this->b = a-b;
	}
};

class derived : public base
{
	public:
	void getdata()
	{
		cout << "A:- "<< this-> a  << " B:- "<< this->b << "\n";
	}
};


int main()
{
	//base b;
	//derive d1;
	base *ptr;
	base b;
	derived d;
	//ptr = &b;

	ptr = &d;
	int x=5, y=7;
	ptr->input(x,y);
	// ptr->getdata(); //error
	((derived *)ptr)->getdata(); 
	//derived *ptr1;
	//ptr1 = &b;
	//ptr1->input(x,y);
	return 0; 
}
