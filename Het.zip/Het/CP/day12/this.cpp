#include<iostream>
using namespace std;
class base 
{
	int a,b;
	public:
	void input (int a, int b)
	{
		this->a = a+b;
		this->b = a-b;
	}
	void getdata()
	{
		cout << "A:- "<< this->a  << " B:- "<< this->b << "\n";
	}
};
int main()
{
	//base b;
	//derive d1;
	base d;
	int a=5, b=7;
	d.input(a,b);
	d.getdata();
	return 0; 
}
