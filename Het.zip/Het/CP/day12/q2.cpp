#include<iostream>
using namespace std;
class base1 
{
	int x;
	public:
	base1()
	{
		cout << "perernt 1 cunstructer \n";
	}
	base1(int x)
	{
		cout << "perernt 1 cunstructer "<< x <<"\n";
	}
	~base1()
	{
		cout << "perernt 1 disstructer \n";
	}
};

class base2 
{
	int x;
	public:
	base2()
	{
		cout << "perernt 2 cunstructer \n";
	}
	base2(int x)
	{
		cout << "perernt 2 cunstructer "<< x <<"\n";
	}
	~base2()
	{
		cout << "perernt 2 disstructer \n";
	}
};

class derive : public base1, virtual public base2
{
	int x;
	public:
	derive()
	{
		cout << "Child cunstructer \n";
	}
	derive(int y)
	{
		cout << "Child peramester cunstructer " << y << "\n" ;
	}
	derive(int y, int z, int a) : base1(z), base2(a) 
	{
		cout << "Child peramester cunstructer " << y << "\n" ;
	}
	~derive()
	{
		cout << "Child disstructer \n";
	}
};

int main()
{
	//base b;
	//derive d1;
	derive d2(20,30,40);
}
