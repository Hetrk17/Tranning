#include<iostream>
using namespace std;
	
class base 
{
	int x;
	public:
	base()
	{
		cout << "perernt cunstructer \n";
	}
	base(int x)
	{
		cout << "perernt cunstructer "<< x <<"\n";
	}
	~base()
	{
		cout << "perernt disstructer \n";
	}
};


class derive : public base
{
	int x;
	public:
	derive()
	{
		cout << "Child cunstructer \n";
	}
	derive(int y)
	{
		cout << "Child peramester cunstructer " << y << "\n" ;
	}
	derive(int y, int z) : base(z)
	{
		cout << "Child peramester cunstructer " << y << "\n" ;
	}
	~derive()
	{
		cout << "Child disstructer \n";
	}
};

int main()
{
	//base b;
	derive d1;
	derive d2(20,30);
}
