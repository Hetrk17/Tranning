#include<iostream>
using namespace std;

class Person
{
    protected:
	int age=25, weight=50,hight=6;
	//Person(int a, int w, int h)
	//{
	//	age = a;
	//	weight = w;
	//	hight = h;
	//}  
	public:
	void print()
	{
		cout << "Class Person \n"
		cout << "Age:- " << age << "\n";
		cout << "weight:- " << weight << "\n";
		cout << "hight:- " << hight << "\n";
		//cout << "selery:- " << selery << "\n";
	}
};

class Doctor : public Person
{
    protected:
	int selery=20000;
	//Doctor(int a, int w, int h, int s)
	//{
	//	age = a;
	//	weight = w;
	//	hight = h;
	//	selery = s;
	//}  
	public:
	void print()
	{
		cout << "Age:- " << age << "\n";
		cout << "weight:- " << weight << "\n";
		cout << "hight:- " << hight << "\n";
		cout << "Selery:- " << selery << "\n";
	}
};

int main()
{
	Person p1;
    	p1.print();
	p1.print1();
	Doctor D1;
    	D1.print();
	return 0;
}
