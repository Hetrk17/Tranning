#include<iostream>
using namespace std;

class Person
{
    public:
	int a1=25;
	void fun1()
	{
		cout << " Perent Public:- " << a1 << "\n";
	}
    protected:
	int a2 = 30;
	void fun2()
	{
		cout << "Perent protected:- " << a2 << "\n";
	}
    private:
	int a3 = 40;
	void fun3()
	{
		cout << "Perent private:- " << a3 << "\n";
	}
};

class Doctor : public Person
{
    
	public:
	int a4 = 50;
	void print()
	{
		cout << "\n\n\n Child 1\n";
		cout << "Child class:- " << a4 << "\n";
		cout << "Child Public:- " << a1 << "\n";
		cout << "Child protected:- " << a2 << "\n";
		//cout << "private:- " << a3 << "\n"; //error
		fun1(); 
		fun2();
		//fun3();  error
	}
};

//Multilavel
class Doctor_child : public Doctor
{
	 public:
	int a5 = 60;
	void print1()
	{
		cout << "\n\n\n Child 2\n";
		cout << "Child class:- " << a5 << "\n";
		cout << "Child 2 class:- " << a4 << "\n";
		cout << "Child 3 public:- " << a1 << "\n";
		cout << "Child 3 protected:- " << a2 << "\n";
		//cout << "private:- " << a3 << "\n"; //error
		fun1(); 
		fun2();
		//fun3();  error
	}
};

int main()
{
	Person p1;
	p1.fun1();
	Doctor D1;
    	D1.print();
	Doctor_child D2;
    	D2.print1();

	return 0;
}
