#include<iostream>
using namespace std;

class A
{
    protected:
	int a1=25;
	void fun1()
	{
		cout << " Perent A Public:- " << a1 << "\n";
	}
};

class B
{
    protected:
	int a2=25;
	void fun2()
	{
		cout << " Perent B Public:- " << a2 << "\n";
	}
};

class C: public A, public B
{
    
	public:
	int a4 = 50;
	void print()
	{
		cout << "\n\n\n Child 1\n";
		cout << "Child class:- " << a4 << "\n";
		cout << "Perent A :- " << a1 << "\n";
		cout << "Perent B :- " << a2 << "\n";
		//cout << "private:- " << a3 << "\n"; //error
		fun1(); 
		fun2();
		//fun3();  error
	}
};

//Mulpllavel
class D : public C
{
	 public:
	int a5 = 60;
	void print1()
	{
		cout << "\n\n\n Child 2\n";
		cout << "Child class:- " << a5 << "\n";
		cout << "Perent C:- " << a4 << "\n";
		cout << "Perent A :- " << a1 << "\n";
		cout << "Perent B :- " << a2 << "\n";
		//cout << "private:- " << a3 << "\n"; //error
		fun1(); 
		fun2();
		//fun3();  error
	}
};

int main()
{
	//A p1;
	//p1.fun1();
	C C1;
    	C1.print();
	D D1;
    	D1.print1();

	return 0;
}
