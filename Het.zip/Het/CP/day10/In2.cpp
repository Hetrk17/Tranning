#include<iostream>
using namespace std;

class Person
{
    public:
	int a1=25;
	void fun1()
	{
		cout << " Perent Public:- " << a1 << "\n";
	}
    protected:
	int a2 = 30;
	void fun2()
	{
		cout << "Perent protected:- " << a2 << "\n";
	}
    private:
	int a3 = 40;
	void fun3()
	{
		cout << "Perent private:- " << a3 << "\n";
	}
};

class Doctor : public Person
{
    
	public:
	int a4 = 50;
	void print()
	{
		cout << "Child class:- " << a4 << "\n";
		cout << "Child Public:- " << a1 << "\n";
		cout << "Child protected:- " << a2 << "\n";
		//cout << "private:- " << a3 << "\n"; //error
		fun1(); 
		fun2();
		//fun3();  error
	}
};

//Multilavel


int main()
{
	Person p1;
	p1.fun1();
	Doctor D1;
    	D1.print();

	return 0;
}
