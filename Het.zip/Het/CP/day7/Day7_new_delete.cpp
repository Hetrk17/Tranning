#include<iostream>
using namespace std;

int main()
{
	int *ptr1, *ptr2, sum;
	ptr1 = new int;
	ptr2 = new int;
	cout << "Enter first number: ";
	cin >> *ptr1;
	cout << "Enter Second number: ";
	cin >> *ptr2;
	sum = *ptr1 +*ptr2;
	cout << "Sum of pointer variable is " << sum << "\n";
	delete ptr1;
	delete ptr2;
	return 0;
}
