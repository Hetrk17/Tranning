#include<iostream>
using namespace std;

class A
{
    public:
	int a1=25;
	void fun1()
	{
		cout << " A Public:- " << a1 << "\n";
	}
};

class B : public virtual A
{
    public:
	int a2=30;
	void fun2()
	{
		cout << " child B Public:- " << a2 << "\n";
		cout << " Perent A Public:- " << a1 << "\n";
	}
};

class C: public virtual A
{
    
	public:
	int a3 = 50;
	void fun3()
	{
		cout << " child C Public:- " << a3 << "\n";
		cout << " Perent A Public:- " << a1 << "\n";
	}
};

//Mulpllavel
class D : public B, public C 
{
	 public:
	int a4 = 60;
	void print1()
	{
		cout << "\n\n\n Child 2\n";
		cout << "Child class:- " << a4 << "\n";
		cout << "Perent C:- " << a3 << "\n";
		cout << "Perent B :- " << a2 << "\n";
		cout << "Perent A :- " << a1 << "\n"; //error
	}
};

int main()
{
	//A p1;
	//p1.fun1();
	D D1;
    	D1.print1();

	return 0;
}
