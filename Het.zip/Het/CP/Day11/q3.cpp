#include<iostream>
using namespace std;

class ABC
{
	public:
	int i,j;
	void display(int i, int j)
	{
		cout <<i<< " " << j <<" This is Perent class\n";
	}
};

class XYZ : public ABC
{
	public:
	void display(int x, int y)
	{
		cout <<x<< " " << y<<" This is child class\n";
		
	}
};

int main()
{
	XYZ x;
	//derived2 ob2;  
	x.display(10,50);
	x.ABC::display(20,30);
	//ob2.set(3,4);
	//ob2.show();
	return 0; 
}
