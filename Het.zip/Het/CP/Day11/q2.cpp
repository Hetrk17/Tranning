#include<iostream>
using namespace std;

class base
{
	private:
	int i,j;
	public:
	void set(int a, int b)
	{
		i=a;
		j = b;
	}
	void show()
	{
		cout << i << " " << j << "\n";
	}
};

class derived1 : public base
{
		public:
	int k;

	void setd1() 
	{
		set(1,2);
		k = (i*j); 
	}
	void showk()
	{
		cout << "K = " << k<< "\n";
		//show();
		
	}
};


//class derived2 : public derived1
//{
//	int m;
//	public:
//	void setd2() 
//	{
//		k = (i-j); //error
//	}
//	void showk()
//	{
//		cout << "M = " << m<< "\n";
//	}
//};

int main()
{
	derived1 ob1;
	//derived2 ob2;  
	ob1.setd1();
	ob1.showk();
	//ob2.set(3,4);
	//ob2.show();
	return 0; 
}
