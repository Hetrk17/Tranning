#include<iostream>
using namespace std;

class base
{
	int i,j;
	public:
	void set(int a, int b)
	{
		i=a;
		j = b;
	}
	void show()
	{
		cout << i << " " << j << "\n";
	}
};

class derived : protected base
{
	int k;
	public:
	derived(int x) 
	{
		k = x;
	}
	void showk()
	{
		cout << k<< "\n";
		cout << "Calling the protected perent function\n";
		set(10,20); // posible becouse the perent class is protected
		show();
	}
};

int main()
{
	derived ob(3);
	//ob.set(1,2); // not allow becouse the perent class is not public
	//ob.show();
	ob.showk();
	return 0; 
}
