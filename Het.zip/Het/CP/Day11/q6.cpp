#include<iostream>
using namespace std;
	
class base
{
	int x;
	public:
	base()
	{
		cout << "perernt cunstructer \n";
	}
};

class derive : public base
{
	int x;
	public:
	derive()
	{
		cout << "Child cunstructer \n";
	}
	derive(int y)
	{
		cout << "Child peramester cunstructer " << y << "\n" ;
	}
};

int main()
{
	//base b;
	derive d1;
	derive d2(20);
}
