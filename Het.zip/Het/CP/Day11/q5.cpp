//Hibid overridding
#include<iostream>
using namespace std;

class A
{
    public:
	//int a1=25;
	void fun1()
	{
		cout << " Class A \n";
	}
};

class B : virtual public A
{
    public:
	//int a2=25;
	void fun1()
	{
		cout << " Class B \n";
	}
};

class C: virtual public A
{
    
	public:
	//int a3 = 50;
	void fun1()
	{
		cout << " Class C \n";
	}
	
};

//Mulpllavel
class D : public B, public C 
{
	 public:
	void fun1()
	{
		cout << " Class D \n";
	}
	
};

int main()
{
	//A p1;
	//p1.fun1();
	D D1;
    	D1.fun1();
	D1.B::fun1();
	D1.C::fun1();
	D1.A::fun1();
	//x.B::fun1();

	return 0;
}
