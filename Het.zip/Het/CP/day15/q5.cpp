//Read a word
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file, file2;
	string str;
	char ch;
	file.open("file.txt");
	file2.open("file1.txt");
	
	if(!file)
	{
		cout << "The file cannot open" << endl; 
	}
	else
	{
		file.get(ch);		
		while(!file.eof())
		{
			file2<<ch;
			file.get(ch);
			
		}
	}
	return 0;
}

