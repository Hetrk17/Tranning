//line read 
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file;
	string str;
	file.open("file2.txt",ios::in);
	
	if(!file)
	{
		cout << "The file cannot open" << endl; 
	}
	else
	{		
		while(getline(file,str,'\t'))
		{
			cout << str << endl;
			
		}
	}
	return 0;
}

