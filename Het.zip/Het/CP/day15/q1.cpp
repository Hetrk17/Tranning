//Read a word
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file;
	string str;
	file.open("file.txt",ios::in);
	
	if(!file)
	{
		cout << "The file cannot open" << endl; 
	}
	else
	{
		file >> str;		
		while(!file.eof())
		{
			cout << str << " ";
			file >> str;
			
		}
		cout << "\n";
	}
	return 0;
}

