//Read a word
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file;
	int count;
	count =0;
	string str;
	char ch;
	file.open("file.txt");
	
	
	if(!file)
	{
		cout << "The file cannot open" << endl; 
	}
	else
	{
		file.get(ch);		
		while(!file.eof())
		{
			if(ch == ' ')
			{
				count++;	
			}
			file.get(ch);
			
		}
	}
	cout << "Total Number of space is " << count << endl;
	return 0;
}

