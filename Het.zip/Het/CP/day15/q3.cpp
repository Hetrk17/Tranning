//line read 
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file;
	string str;
	file.open("file2.txt",ios::in);
	
	try
	{
		f.open("student.txt", ios::in);
		if(!f)
		{
	  		throw 5;
	     	}
	}
	catch(int x)
	{
	    	cout << "File not found\n";
	     	exit (0);
	}
			
	while(getline(file,str,','))
	{
		cout << str << "\t" <<endl;
	}
	return 0;
}

