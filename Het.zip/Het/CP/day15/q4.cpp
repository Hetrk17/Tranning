//Read a word
#include<fstream>
#include<iostream>
using namespace std;

int main()
{
	fstream file;
	string str;
	int count;
	count = 0;
	file.open("file.txt",ios::in);
	
	if(!file)
	{
		cout << "The file cannot open" << endl; 
	}
	else
	{
		file >> str;		
		while(!file.eof())
		{
			count++;
			cout << str << endl;			
			file >> str;
			
		}
	}
	cout << "Total word is "<<count<<endl;
	return 0;
}

