#include<fstream>
#include<iostream>
#include<string>
using namespace std;

template <class T1>
void sum(T1 a, T1 b, T1 c)
{
	cout<< "Sum: " << a+b+c << endl;
}

template <class T1, class T2>
void sum(T1 a, T2 b, T1 c)
{
	cout<< "Sum: " << a+b+c << endl;
}

void sum(int a, int b)
{
	cout << "Sum: " << a+b << endl;
}

int main()
{
	int a =1, b= 2, c= 3;
	float A=1.1, B = 2.2, C=3.3;
	sum(a,b,c);
	sum(a,B,c);
	sum(a,b);
	// sum(A,B,c); //error
	return 0;
}
