#include<fstream>
#include<iostream>
#include<string>
using namespace std;

template <class T>

void swap1(T *n1, T *n2)
{
	cout<<"Inside Template"<<endl;
	T temp;
	temp = *n1;
	*n1 = *n2;
	*n2 = temp;
	
}

void swap1(int *n1, int *n2)
{
	cout<<"Not Template"<<endl;
	int temp;
	temp = *n1;
	*n1 = *n2;
	*n2 = temp;
	
}

int main()
{
	int A = 10, B =11;
	float a = 10.5, b =  11.3;
	double e = 12.5, f =  13.3;
	
	cout << "Integer\n";
	cout << "Before Swap"<<" "<<A<<" "<< B <<"\n";
	swap1(&A,&B);
	cout << "After Swap"<<" "<<A<<" "<< B <<"\n";
	
	cout << "\nFloat\n";
	cout << "Before Swap"<<" "<<a<<" "<< b <<"\n";
	swap1(&a,&b);
	cout << "After Swap"<<" "<<a<<" "<< b <<"\n";
	
	cout << "\ndouble\n";
	cout << "Before Swap"<<" "<<e<<" "<< f <<"\n";
	swap1(&e,&f);
	cout << "After Swap"<<" "<<e<<" "<< f <<"\n";
	return 0;
}
