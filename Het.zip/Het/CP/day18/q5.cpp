#include<iostream>
#include<string>
using namespace std;

template <class T,int N>

class Myarray
{
	T memblock [N];
	public:
		void setmember(int x, T value);
		T getmember(int x);
};
template <class T,int N>
void Myarray<T,N> :: setmemeber(int x, T value)
{
	memblock[x] = value;
}
template <class T,int N>
T Myarray<T,N> :: getmemeber(int x)
{
	T value;
	value = memblock[x];
	return value;
}

int main()
{
	Myarray<int,5> arryin;
	Myarray<double,5> arryfl;
	
	arryin.setmemeber(0,100);
	arrayfl.setmemeber(3,3.14);
	
	cout<<arryin.getmemeber(0)<<endl;
	cout<<arrayfl.getmemeber(3)<<endl;
	return 0;
}
