#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
pthread_t tid1,tid2;
void *thr_fn(void *arg)
{
	int num = (int *)arg; 
	printf("Inside Thread %d\n",num);
	printf("Process ID %d: %u\n",num,(unsigned int)(getpid()));
	printf("Thread ID %d: %u\n",num,(unsigned int)(pthread_self()));
	return 0;
}
int main(void)
{
	int err;
	err = pthread_create(&tid1,NULL,thr_fn,1);
	err = pthread_create(&tid2,NULL,thr_fn,2);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	exit(0);
}
