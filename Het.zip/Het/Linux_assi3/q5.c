#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
pthread_mutex_t my_mutex;
char sharedVar = 'A';


void* theradfunc_B(void *arg)
{
	pthread_mutex_lock(&my_mutex);
	sharedVar = 'B';
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	//sleep(3);
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'B';
	pthread_mutex_unlock(&my_mutex);
}

void* theradfunc_C(void *arg)
{
	pthread_mutex_lock(&my_mutex);
	sharedVar = 'C';
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	for(int i =0; i<50000; i++);
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'C';
	pthread_mutex_unlock(&my_mutex);
}
int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	int err;
	pthread_create(&tid1, NULL, theradfunc_B, NULL);
	pthread_create(&tid2, NULL, theradfunc_C, NULL);
	
	printf("sharedVar = %c \n\n\n ", sharedVar);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	exit(0);
}
