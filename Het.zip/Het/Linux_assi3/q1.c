#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>

char sharedVar = 'A';


void* theradfunc_B(void *arg)
{
	sharedVar = 'B';
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	sleep(3);
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'B';
	return 0;
}

void* theradfunc_C(void *arg)
{
	
	sharedVar = 'C';
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	sleep(4);
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'C';
	return 0;
}
int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	int err;
	pthread_create(&tid1, NULL, theradfunc_B, NULL);
	pthread_create(&tid2, NULL, theradfunc_C, NULL);
	
	printf("sharedVar = %c \n\n\n ", sharedVar);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	exit(0);
}
