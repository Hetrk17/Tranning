#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

void *Proc(void *param)
{
	sleep(2);
	return 0;
}
int main()
{
	pthread_attr_t Attr;
	pthread_t Id;
	void *Stk;
	size_t Siz;
	int err;

	size_t my_stksize = 0x3000000;
	//size_t my_stksize = 0x100; // thread can not allot the stack size.
	void *my_stack;
	int priority,policy,ret;
	struct sched_param param;

	pthread_attr_init(&Attr);

	pthread_attr_getstacksize(&Attr,&Siz);
	pthread_attr_getstackaddr(&Attr,&Stk);
	
	
	pthread_attr_getschedparam(&Attr,&param);
	printf("\n-----------------Main Thread------------------------\n");
	printf("Policy:- %d, Priority:- %d\n",policy,param.sched_priority);

	printf("Default: Addr=%08x default size = %d\n",Stk,Siz);

	my_stack = (void *)malloc(my_stksize);
	policy = SCHED_FIFO;
	param.sched_priority = 3;

	printf("MALLOC checking : Addr=%08x and Size=%d\n",my_stack,my_stksize);

	pthread_attr_setstack(&Attr,my_stack,my_stksize);
	pthread_setschedparam(&Attr,policy,&param);
	pthread_attr_getstack(&Attr,&Stk,&Siz);
	pthread_create(&Id,&Attr,Proc,NULL);
	
	printf("\n-----------------Updeted Thread------------------------\n");
	printf("Policy Updeted\n");
	printf("newly defined stack : Addr=%08x and Size=%d\n",Stk,Siz);
	pthread_getschedparam(&Attr,policy,&param);
	printf("Policy:- %d, Priority:- %d\n",policy,param.sched_priority);
	
	
	
	

	sleep(3);

	return(0);

}

