#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<fcntl.h>


void *printHello(void *threadid)
{
	printf("Thread Called\n");
	int count =0;
	while(1)
	{  
		printf("wait till thraed call cancel itself\n");
		for(int i=0; i<800000; i++); //random delay
		count++;
		if(count == 5)
		{
			printf("Now thread killes itself\n");
			for(int i=0; i<800000; i++); //random delay
			int t=pthread_cancel(pthread_self());
			if(t==0)
				printf("\n Thread Canceld\n");
		}
			
	}
	//infinate loop so that we can ansore that the thread is call thread cancel itself
}

int main()
{
	pthread_t thread;
	int rc,t=0;
	printf("Creating thred \n");
	rc = pthread_create(&thread, NULL,printHello,NULL);
	printf("\nThread ID : %u \n", thread);
	pthread_join(thread,NULL);
	//printf("\n thread ID : %u \n",thread);
}
