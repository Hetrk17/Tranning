#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
static void* threadFunc(void *arg)
{
	char *s = (char *) arg;
	int i, j;
	for (i=0; i<10; i++) 
	{
		for (j=0; j<500000000; j++);   // Delay
		printf("%s is exicuting \n",s);
	}
	return 0;
}

int main(int arg, char *ardv[])
{
	pthread_t t1;
	void *res;
	int s;
	pthread_create(&t1 , NULL , threadFunc , "Thread 1");
	printf("main() Process termineted\n");
	pthread_exit(NULL);
}

