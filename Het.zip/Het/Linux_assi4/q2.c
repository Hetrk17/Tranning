#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<pthread.h>
#include<string.h>


struct params
{
	int count;
	char str[50];
};

void* threadFunc(void *arg)
{
	struct params *p = (struct params *) arg;
	int i;
	printf("In the thread function\n");
	printf("String data: %s", p->str);
	printf("Count %d\n", p->count);
}

int main(int argc, char *argv[])
{
	pthread_t t1;
	struct params par1;
	strcpy(par1.str,"Hi I am Het\n");
	par1.count = 20;
	pthread_create(&t1, NULL, threadFunc, (void *)&par1);
	printf("Messages from main()\n");
	sleep(3);
	pthread_join(t1, NULL);
	return 0;
}
