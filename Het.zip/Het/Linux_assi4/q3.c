#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
#include<semaphore.h>

pthread_once_t once = PTHREAD_ONCE_INIT;
void *myinit()
{
	printf("init function called only one time\n");
}
void* theradfuna(void *arg)
{
	printf("****************************Function a thread %d **************************** \n\n", (int *)arg);
	pthread_once(&once,(void *)myinit);	
	//sleep(1);
	printf("****************************%d Thread Completed****************************\n\n\n\n",(int *)arg);
}

void* theradfunb(void *arg)
{
	printf("****************************Function b thread %d **************************** \n\n", (int *)arg);
	pthread_once(&once,(void *)myinit);	
	printf("**************************** %d Thread Completed ****************************\n\n\n\n",(int *)arg);
}

void* theradfunc(void *arg)
{
	printf("**************************** Function c thread %d **************************** \n\n", (int *)arg);
	pthread_once(&once,(void *)myinit);	
	printf("**************************** %d Thread Completed ****************************\n\n\n\n",(int *)arg);
}

int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2,tid3;
	pthread_create(&tid1, NULL, theradfuna, (void *)1);
	pthread_create(&tid2, NULL, theradfunb, (void *)2);
	pthread_create(&tid3, NULL, theradfunc, (void *)3);
	sleep(3);
	printf("Main Completed\n");
	pthread_exit(NULL);
	exit(0);
}
