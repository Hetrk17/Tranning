#include<pthread.h>
#include<stdlib.h>
#include<stdio.h>
char sharedVar = 'A';
static pthread_spinlock_t spinlock;
volatile int slock;
int rc;
void* theradfunc_B(void *arg)
{
	rc = pthread_spin_lock(&slock);
	if(rc==0)
	{
		printf("***********************************************************************\n");
		printf("Thread B, sucessfully lock the spin lock\n");
	}
	else
	{
		printf("***********************************************************************\n");
		printf("Thread B, Not lock the spin lock\n");
	}
	sharedVar = 'B';
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	sleep(3);
	printf("In threadfunc_B\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'B';
	rc = pthread_spin_unlock(&slock);
	if(rc==0)
	{
		printf("Thread B, sucessfully unlock the spin lock\n");
		printf("***********************************************************************\n\n\n\n\n");
	}
	else
	{
		printf("Thread B, Not unlock the spin lock");
		printf("***********************************************************************\n\n\n\n\n");
	}
}

void* theradfunc_C(void *arg)
{
	rc = pthread_spin_lock(&slock);
	if(rc==0)
	{
		printf("***********************************************************************\n");
		printf("Thread C, sucessfully lock the spin lock\n");
	}
	else
	{
		printf("***********************************************************************\n");
		printf("Thread C, Not lock the spin lock\n");
	}
	sharedVar = 'C';
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	sleep(3);
	printf("In threadfunc_C\nsharedVar   = %c\n\n\n", sharedVar); 
	sharedVar = 'C';
	rc = pthread_spin_unlock(&slock);
	if(rc==0)
	{
		printf("Thread C, sucessfully unlock the spin lock\n");
		printf("***********************************************************************\n\n\n\n\n");
	}
	else
	{
		printf("Thread C, Not unlock the spin lock\n");
		printf("***********************************************************************\n\n\n\n\n");
	}
}
int main(int arg, char *ardv[])
{
	pthread_t tid1,tid2;
	pthread_spin_init(&slock,PTHREAD_PROCESS_PRIVATE);
	int err;
	
	printf("sharedVar = %c \n\n\n", sharedVar);
	pthread_create(&tid1, NULL, theradfunc_B, NULL);
	sleep(3);
	pthread_create(&tid2, NULL, theradfunc_C, NULL);
	
	
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	
	exit(0);
}
